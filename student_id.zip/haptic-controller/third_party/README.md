# Vendored build dependencies

The following official files are included unchanged so the submitted project does
not need to download SDK dependencies to build. Their original licenses and
copyright notices are retained. These are third-party code, not student work.

* STMicroelectronics/cmsis-device-c0, commit
  `bcc8d94fecb767d1afb53d8c12a8f87ebeb503a2`: `stm32c031xx.h`,
  `system_stm32c0xx.h`, and BSD-3-Clause `LICENSE.md`.
* ARM-software/CMSIS_5, commit
  `55b19837f5703e418ca37894d5745b1dc05e4c91`: the GCC Cortex-M0+ core
  headers and Apache-2.0 `LICENSE.txt`.

Pin mappings were checked against STMicroelectronics/STM32_open_pin_data,
`mcu/STM32C031C(4-6)Tx.xml` and its
`GPIO-STM32C0xx_453_gpio_v1_0_Modes.xml` database. This database is a reference
only and is not required at build time.
