# Assignment 2 — STM32C031C6 haptic controller

This ZIP contains the complete C project, official device headers, a prebuilt
firmware image, and a VS Code / Wokwi circuit. The authoritative specification is
`assignment.pdf` (ENGE X200 Assignment 2); its formulas and one-sided disengagement
deadband take precedence over the earlier System Overview.

**Attribution:** the custom implementation and draft report were generated with
OpenAI Codex. The assignment says AI may be used only for editing and prohibits
AI-generated code. Do not represent this project as independently written student
work or assume it is eligible for assessment submission.

## Open and run

1. Extract this ZIP and open the extracted project folder in VS Code. The files
   `wokwi.toml` and `diagram.json` must be at the workspace root.
2. Install **Wokwi Simulator** (`wokwi.wokwi-vscode`) and activate it through your
   own Wokwi account. No token or license is embedded in this project.
3. The supplied `build/haptic.hex` and `build/haptic.elf` can be loaded immediately.
   Select **Wokwi: Start Simulator** from the VS Code command palette.
4. To rebuild, install GNU Arm Embedded GCC (with newlib) and GNU Make, then run
   `make` or the default VS Code build task. The command `arm-none-eabi-gcc` must
   be on PATH; a prefix can be overridden with `make ARM_PREFIX=/path/to/arm-none-eabi-`.
5. Optional developer verification: `make test` needs a native C compiler (`cc`).
   This exercises the actual control module; it is not a Wokwi simulation.

The updated startup explicitly initializes the interrupt vector base before
SysTick starts. This follows ST's SystemInit and removes reliance on a flash
alias at address zero. A missing vector base was found while investigating the
reported red-light-only behavior; the corrected image still needs a Wokwi run.

This version prints status messages to the Wokwi Terminal at 115200 baud using
USART1 TX on PA9. The diagram connects this otherwise unused pin to the serial
monitor. Look for `HAPTIC DIAGNOSTIC v2`, `MPU INIT OK`, and periodic
`STATUS ... SENSOR OK` messages. A successful press prints `BUTTON PRESS DETECTED`.
If initialization fails, the log gives the I2C phase and status register. These
messages diagnose the system without bypassing sensor validation or mode guards.

The reported v1 Wokwi run reached BOOT OK but timed out waiting for RXNE during
WHO_AM_I, with ISR=0x00008043 (the completed write-phase flags were still set).
Version 2 configures I2C direction/count with START clear before requesting START
in a separate register write. If the initial repeated-START identity read fails,
it retries with a STOP after the pointer write and a fresh addressed read. Sensor
identity and actual received samples remain mandatory. The chosen transaction
style is logged. The v2 bus change needs confirmation in Wokwi; the passing host
control tests do not exercise its peripheral model.

All code and dependencies required for compilation are inside this project.
No STM32CubeIDE, HAL download, generated code step, Python package or network
dependency is needed to compile it. Vendor licenses are in `third_party/`.

## Behavior and circuit

The firmware reads MPU6050 acceleration at address `0x68` every 20 ms, at the same
rate as the 50 Hz servo update. Its `angles_from_accel()` subroutine calculates
pitch = atan2(-ax, sqrt(ay² + az²)), roll = atan2(ay, az), and combined tilt =
sqrt(pitch² + roll²), all in degrees. Accelerometer scale is ±2g, 16384 LSB/g.

| Function | Pin | Configuration |
| --- | --- | --- |
| Pitch servo | PB5 | TIM3 CH2, AF1 |
| Roll servo | PB4 | TIM3 CH1, AF1 |
| Tilt servo | PB0 | TIM3 CH3, AF1 |
| Autopilot / manual LEDs | PA2 / PB11 | Active-high outputs, 330 ohm series resistors |
| External mode button | PA12 | Active-high input, internal pull-down |
| MPU6050 SCL / SDA | PB8 / PB9 | I2C1 AF6 open drain, external 4.7k pull-ups to 3.3V |

The diagram uses the external button, not the board's PC13 button. MPU6050 AD0 is
grounded. The sensor is powered from 3.3V; servos use 5V and share ground. On real
hardware, use an appropriately rated external servo supply with a common ground;
do not power three loaded servos from the MCU's 3.3V output. I2C is configured for
Fast-mode below the MPU6050's 400 kHz maximum, rather than the overview's 1 MHz.

At 48 MHz, TIM3 PSC=47 and ARR=19999 give a 1 us timer tick and 20 ms period.
Servo commands map 0–180° to 1000–2000 us. Pitch and roll are neutral at 90°;
tilt is neutral at 0°. Compliant pitch/roll commands are 90° + angle, clamped
to 40–140°; compliant tilt is twice the combined tilt, capped at 140°.

Pitch/roll enter compliant at magnitude >=30° and clamp at >=50°. On return,
clamp releases at <=45°, and compliant releases at <=25°. Tilt enters compliant
at >=20° and clamp at >=70°, releasing at <=65° and <=15°. The assignment omits
the equality case at some thresholds; these inclusive choices make every input
deterministic. A large sample can jump directly between free and clamp states.

Startup mode is AUTOPILOT. A debounced press allows MANUAL only when both axes
are in FREE and strictly inside ±30°. A press in MANUAL always returns to
AUTOPILOT, as does both axis regions being CLAMP. Unsafe presses are consumed,
not queued. Feedback remains active in both modes because no separate autopilot
servo trajectory is specified. Faults force AUTOPILOT and neutral outputs;
recovery never silently restores MANUAL. LED outputs indicate mode, not fault.

## Results and required recording

Verified in the development environment: a clean GNU Arm GCC 14.2.1 firmware
build passes strict C11 warnings, using 10936 bytes of flash and 144 bytes of
static RAM (stack use is additional). `make test` passes 7372 host checks,
including 253 normalized gravity vectors, region boundaries, servo saturation,
mode transitions, faults, debounce and PWM mapping. These software checks do not
validate the simulated I2C/PWM peripherals or physical hardware.

**No Wokwi screen recording is supplied.** Compilation and host test results are
not evidence that the peripheral simulation or physical hardware has been run.
Before final submission, make a genuine Wokwi screen recording, add it to the ZIP
as `results.mp4`, and update the report with observed simulation results. Replace
`Student Name (student_id)` in `diagram.json` and rename the two submission files
using your actual student ID. The report currently identifies predictions and
software tests explicitly; it does not invent simulation observations.

Use these normalized acceleration triples (g) to record the required cases.
Start from level before independent entry tests; wait for outputs to settle.
The Wokwi sliders may quantize values, so record the actual settings used.

| Case | ax | ay | az | Expected angles / response |
| --- | ---: | ---: | ---: | --- |
| Level | 0 | 0 | 1 | All FREE; servos 90°,90°,0° |
| Roll-only orientation | 0 | 0.642788 | 0.766044 | roll +40°, pitch 0°; roll 130°, tilt 80° |
| Pitch-only orientation | -0.642788 | 0 | 0.766044 | pitch +40°, roll 0°; pitch 130°, tilt 80° |
| Tilt-only feedback | -0.309017 | 0.293893 | 0.904508 | pitch/roll +18°, tilt25.456°; axes90°, tilt50.912° |
| Positive pitch clamp | -0.866025 | 0 | 0.5 | pitch+60°; pitch140°, tilt120° |
| Negative roll clamp | 0 | -0.866025 | 0.5 | roll-60°; roll40°, tilt120° |
| Both clamped | -0.866025 | 0.433013 | 0.25 | pitch/roll+60°, tilt84.853°; all140°, AUTOPILOT |

For release hysteresis, slowly sweep an isolated axis 60→48→44→28→24°;
expected states are CLAMP, CLAMP, COMPLIANT, COMPLIANT, FREE. Sweep tilt through
75→68→64→18→14° using the corresponding isolated-angle gravity vector.
Some transient slider combinations need not have unit magnitude, as the brief
permits this during demonstrations. Each settled reported test triple must be
approximately 1g. For mode transitions: at level press to MANUAL, hold the button
to prove it produces one event, release, press to AUTOPILOT; try an unsafe press
at40°; finally enter MANUAL at level and apply the both-clamped triple.

The original overview uses different formulas and ±5° entry shifts; its numeric
examples must not be used to judge this implementation. In particular, isolated
pitch or roll at40° also activates tilt feedback because alpha=40°.
