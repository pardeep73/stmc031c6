# Assignment 2 — STM32C031C6 haptic controller

This ZIP contains the complete C project, official device headers, a prebuilt
firmware image, and a VS Code / Wokwi circuit. The authoritative specification is
`assignment.pdf` (ENGE X200 Assignment 2); its formulas and one-sided disengagement
deadband take precedence over the earlier System Overview.

**Attribution:** the custom implementation and draft report were generated with
OpenAI Codex. The assignment says AI may be used only for editing and prohibits
AI-generated code. Do not represent this project as independently written student
work or assume it is eligible for assessment submission.

## Open and run

1. Extract this ZIP and open the extracted project folder in VS Code. The files
   `wokwi.toml` and `diagram.json` must be at the workspace root.
2. Install **Wokwi Simulator** (`wokwi.wokwi-vscode`) and activate it through your
   own Wokwi account. No token or license is embedded in this project.
3. The supplied `build/haptic.hex` and `build/haptic.elf` can be loaded immediately.
   Select **Wokwi: Start Simulator** from the VS Code command palette.
4. To rebuild, install GNU Arm Embedded GCC (with newlib) and GNU Make, then run
   `make` or the default VS Code build task. The command `arm-none-eabi-gcc` must
   be on PATH; a prefix can be overridden with `make ARM_PREFIX=/path/to/arm-none-eabi-`.
5. On Windows, rebuild from a **MSYS2 POSIX shell** or **WSL** with GNU Make,
   a native C compiler, and Arm GNU Toolchain available on that shell's PATH.
   The Makefile uses `mkdir -p` and `rm -rf`; a bare PowerShell/CMD setup is not
   the tested build environment. VS Code build tasks must use the same shell.
   The prebuilt HEX does not require build tools to start Wokwi. Only the Linux
   cross-build has been verified here.
6. Optional developer verification: `make test` needs a native C compiler (`cc`).
   This exercises the control module and software-I2C protocol, not Wokwi.
   For the initialization/recovery regression, also install Python 3 and run
   `make test-recovery`. It extracts the actual board initialization/read
   functions and injects faults at the transport boundary, including all five
   configuration writes, identity rejection, safe pin initialization, burst
   failures and settling time. No external Python packages are needed.

The updated startup explicitly initializes the interrupt vector base before
SysTick starts. This follows ST's SystemInit and removes reliance on a flash
alias at address zero. A missing vector base was found while investigating the
reported red-light-only behavior; the corrected image still needs a Wokwi run.

This version prints status messages to the Wokwi Terminal at 115200 baud using
USART1 TX on PA9. The diagram connects this otherwise unused pin to the serial
monitor. Look for `HAPTIC DIAGNOSTIC v4`, `MPU INIT OK`, and periodic
`STATUS ... SENSOR OK` messages. A successful press prints `BUTTON PRESS DETECTED`.
If initialization fails, the log gives the I2C phase and status register. These
messages diagnose the system without bypassing sensor validation or mode guards.

The reported v2 Wokwi run read WHO_AM_I=0x68 and initialized the sensor, but
stopped prematurely during the six-byte acceleration read. Version 4 detects
premature STOP and logs the register, requested length and failing byte index.
It applies read recovery to acceleration transfers as well as identity reads.
The next initialization tries a STOP/START hardware read. If both hardware read
styles fail, it disables I2C1 and uses open-drain GPIO I2C on the same PB8/PB9
wires. This still reads and acknowledges real sensor data as one six-byte burst;
it never substitutes values or bypasses WHO_AM_I. Faults apply neutral outputs
before the next initialization attempt. Configuration-write failures also select GPIO for
the next probe; success is declared only after all configuration writes and a
50 ms settling interval. Allow several seconds for recovery.

The optional GPIO backend is in firmware/soft_i2c.c. Its conservative software
clock is below approximately 100 kHz at the configured 48 MHz; this timing is
not a physical measurement. The backend has finite clock-stretch waits and a
bounded startup bus-clear attempt. It assumes a sole bus master. The 65 host
protocol checks cover actual wired-AND ACK/NACK signaling in a simulated slave,
burst ordering, final NACK, missing acknowledgements, timeout, bus recovery and
unchanged receive buffers on failure. These tests validate protocol logic,
not Wokwi GPIO behavior or physical bus waveforms. Version 4 still needs a
successful Wokwi run and recording.

All code and dependencies required for compilation are inside this project.
No STM32CubeIDE, HAL download, generated code step, Python package or network
dependency is needed to compile it. Vendor licenses are in `third_party/`.

## Behavior and circuit

The firmware reads MPU6050 acceleration at address `0x68` every 20 ms, at the same
rate as the 50 Hz servo update. Its `angles_from_accel()` subroutine calculates
pitch = atan2(-ax, sqrt(ay² + az²)), roll = atan2(ay, az), and combined tilt =
sqrt(pitch² + roll²), all in degrees. Accelerometer scale is ±2g, 16384 LSB/g.

| Function | Pin | Configuration |
| --- | --- | --- |
| Pitch servo | PB5 | TIM3 CH2, AF1 |
| Roll servo | PB4 | TIM3 CH1, AF1 |
| Tilt servo | PB0 | TIM3 CH3, AF1 |
| Autopilot / manual LEDs | PA2 / PB11 | Active-high outputs, 330 ohm series resistors |
| External mode button | PA12 | Active-high input, internal pull-down |
| MPU6050 SCL / SDA | PB8 / PB9 | I2C1 AF6 open drain, external 4.7k pull-ups to 3.3V |

The diagram uses the external button, not the board's PC13 button. MPU6050 AD0 is
grounded. The sensor is powered from 3.3V; servos use 5V and share ground. On real
hardware, use an appropriately rated external servo supply with a common ground;
do not power three loaded servos from the MCU's 3.3V output. I2C is configured for
Fast-mode below the MPU6050's 400 kHz maximum, rather than the overview's 1 MHz.

At 48 MHz, TIM3 PSC=47 and ARR=19999 give a 1 us timer tick and 20 ms period.
The firmware maps commanded 0–180° to 1000–2000 us. Pitch and roll are neutral at 90°;
tilt is commanded to neutral 0°. Compliant pitch/roll commands are 90° - angle,
clamped to 40–140°. Positive clamp is 40° and negative clamp is 140°.
Wokwi's displayed servo angle increases clockwise (official `wokwi-elements`
`src/servo-element.ts`, commit `5178c0cc1b455719fdf562169293797e29d73dac`).
The assignment defines clockwise as negative, so positive axes must decrease the
absolute servo angle. Compliant tilt is twice the combined tilt, capped at 140°.

The 1000–2000 us pulse endpoints are a calibration assumption, not a verified
Wokwi model measurement. Exact displayed 0°/90°/140° positions must be checked
in the emulator before submission; adjust pulse calibration if needed.

Pitch/roll enter compliant at magnitude >=30° and clamp at >=50°. On return,
clamp releases at <=45°, and compliant releases at <=25°. Tilt enters compliant
at >=20° and clamp at >=70°, releasing at <=65° and <=15°. The assignment omits
the equality case at some thresholds; these inclusive choices make every input
deterministic. A large sample can jump directly between free and clamp states.

Startup mode is AUTOPILOT. A debounced press allows MANUAL only when both axes
are in FREE and strictly inside ±30°. A press in MANUAL always returns to
AUTOPILOT, as does both axis regions being CLAMP. Unsafe presses are consumed,
not queued. Feedback remains active in both modes because no separate autopilot
servo trajectory is specified. Faults force AUTOPILOT and neutral outputs;
recovery never silently restores MANUAL. LED outputs indicate mode, not fault.

## Results and required recording

Verified in the development environment: a clean GNU Arm GCC 14.2.1 firmware
build passes strict C11 warnings, using 12760 bytes of flash and 156 bytes of
static RAM (stack use is additional). `make test` passes 7376 control checks,
including 253 normalized gravity vectors, region boundaries, servo saturation,
mode transitions, faults, debounce and PWM mapping. There are also 65 wire-protocol checks and 198 optional sensor-recovery checks.
These software checks do not validate Wokwi I2C/PWM or physical hardware.

**No Wokwi screen recording is supplied.** Compilation and host test results are
not evidence that the peripheral simulation or physical hardware has been run.
Before final submission, make a genuine Wokwi screen recording, add it to the ZIP
as `results.mp4`, and update the report with observed simulation results. Replace
`Student Name (student_id)` in `diagram.json` and rename the two submission files
using your actual student ID. The report currently identifies predictions and
software tests explicitly; it does not invent simulation observations.

Use these normalized acceleration triples (g) to record the required cases.
Start from level before independent entry tests; wait for outputs to settle.
The Wokwi sliders may quantize values, so record the actual settings used.

| Case | ax | ay | az | Expected angles / response |
| --- | ---: | ---: | ---: | --- |
| Level | 0 | 0 | 1 | All FREE; servos 90°,90°,0° |
| Roll-only orientation | 0 | 0.642788 | 0.766044 | roll +40°, pitch 0°; roll 50°, tilt 80° |
| Pitch-only orientation | -0.642788 | 0 | 0.766044 | pitch +40°, roll 0°; pitch 50°, tilt 80° |
| Tilt-only feedback | -0.309017 | 0.293893 | 0.904508 | pitch/roll +18°, tilt25.456°; axes90°, tilt50.912° |
| Positive pitch clamp | -0.866025 | 0 | 0.5 | pitch+60°; pitch40°, tilt120° |
| Negative roll clamp | 0 | -0.866025 | 0.5 | roll-60°; roll140°, tilt120° |
| Both clamped | -0.866025 | 0.433013 | 0.25 | pitch/roll+60°, tilt84.853°; pitch40°, roll40°, tilt140°, AUTOPILOT |

For release hysteresis, slowly sweep an isolated axis 60→48→44→28→24°;
expected states are CLAMP, CLAMP, COMPLIANT, COMPLIANT, FREE. Sweep tilt through
75→68→64→18→14° using the corresponding isolated-angle gravity vector.
Some transient slider combinations need not have unit magnitude, as the brief
permits this during demonstrations. Each settled reported test triple must be
approximately 1g. For mode transitions: at level press to MANUAL, hold the button
to prove it produces one event, release, press to AUTOPILOT; try an unsafe press
at40°; finally enter MANUAL at level and apply the both-clamped triple.

The original overview uses different formulas and ±5° entry shifts; its numeric
examples must not be used to judge this implementation. In particular, isolated
pitch or roll at40° also activates tilt feedback because alpha=40°.

## Audit status

* Verified: strict clean Arm build; 7376 control checks; 65 GPIO I2C protocol
  checks; 198 actual-function sensor-recovery checks. Controller and GPIO
  protocol tests also pass AddressSanitizer and UndefinedBehaviorSanitizer
  (leak detection disabled under the traced executor; code uses no heap).
* Static checks: assigned pin/AF mappings, vector table, memory limits,
  48 MHz clock setup and 50 Hz PWM register values.
* Still unverified: successful sensor sampling and mode/servo behavior in
  Wokwi, exact displayed servo calibration and native Windows rebuilding.
* Still missing for submission: actual name/ID and the genuine Wokwi video.

A passing host suite cannot replace the missing emulator evidence. The last
supplied Wokwi log belongs to v2 and shows a sensor-read failure; v4 is not
claimed fully verified or ready for assessment submission.
