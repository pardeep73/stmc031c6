#ifndef HAPTIC_H
#define HAPTIC_H

/* Generated with OpenAI Codex. See README.md for course-policy attribution.
 * This interface keeps the assignment's mathematical/control logic independent
 * of MCU registers, allowing the same routines to be checked on a host PC. */

#include <stdbool.h>
#include <stdint.h>

typedef enum { REGION_FREE, REGION_COMPLIANT, REGION_CLAMP } region_t;
typedef enum { MODE_AUTOPILOT, MODE_MANUAL } mode_t;

typedef struct {
    float pitch_deg, roll_deg, tilt_deg;
} angles_t;

typedef struct {
    mode_t mode;
    bool fault;
    region_t pitch_region, roll_region, tilt_region;
    float pitch_servo_deg, roll_servo_deg, tilt_servo_deg;
} haptic_t;

typedef struct {
    bool stable, candidate;
    uint32_t changed_ms;
} button_t;

/* Enter at the nominal limit; disengage at the limit minus 5 degrees. */
region_t region_update(region_t previous, float magnitude,
                       float free_boundary, float clamp_boundary);
/* Reject an all-zero acceleration vector; ±2g MPU6050 scale is 16384 LSB/g. */
bool angles_from_accel(int16_t x, int16_t y, int16_t z, angles_t *angles);
void haptic_init(haptic_t *state);
/* NULL or non-finite/out-of-domain angles force neutral and AUTOPILOT. */
void haptic_step(haptic_t *state, const angles_t *angles, bool button_pressed);
/* Debounce for 30 ms; holding a button never generates repeated presses. */
void button_init(button_t *button, bool initial, uint32_t now_ms);
bool button_update(button_t *button, bool raw, uint32_t now_ms);
/* 0..180 degrees -> 1000..2000 us; non-finite input -> neutral 1500 us. */
uint16_t servo_pulse_us(float degrees);

#endif
