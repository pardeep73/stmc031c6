#ifndef SOFT_I2C_H
#define SOFT_I2C_H

#include <stdbool.h>
#include <stdint.h>

/* Generated with OpenAI Codex; see README.md for attribution.
 * Optional sole-master GPIO I2C backend, using real PB8/SCL and PB9/SDA.
 * Caller disables hardware I2C1 before init and must reinitialize it before
 * changing backends again. External 3.3-V pull-ups are required. */
#define SOFT_I2C_MAX_READ 32U

/* Release the lines and, only if SDA is stuck, try at most nine recovery clocks.
 * Call at backend activation/reinitialization, not before every transaction. */
bool soft_i2c_init(void);
bool soft_i2c_write_reg(uint8_t addr, uint8_t reg, uint8_t value);
/* One register-pointer write, repeated START, then one contiguous read burst.
 * ACK every byte except the last. On failure the caller's buffer is unchanged.
 * Returns true only for acknowledged transfers with an observed released bus. */
bool soft_i2c_read_regs(uint8_t addr, uint8_t reg, uint8_t *data, unsigned length);

#endif
