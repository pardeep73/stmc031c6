/* Generated with OpenAI Codex; see README.md for attribution.
 * Poll the MPU6050 and update the feedback FSM every20ms (50Hz).
 * SysTick samples and debounces the button every1ms even during I2C waits. */
#include "board.h"
#include "haptic.h"
#include "stm32c031xx.h"

/* Kept visible to the debugger for inspecting FSM decisions and sample angles. */
haptic_t controls;
angles_t measured_angles;
static button_t mode_button;
static volatile bool button_ready;
static volatile bool button_pending;

void SysTick_Handler(void)
{
    board_tick();
    if (button_ready && button_update(&mode_button, board_button(), board_millis())) {
        button_pending = true;
    }
}

static bool take_button_event(void)
{
    const uint32_t primask = __get_PRIMASK();
    __disable_irq();
    const bool pressed = button_pending;
    button_pending = false;
    __set_PRIMASK(primask);
    return pressed;
}

static void apply_outputs(void)
{
    board_outputs(servo_pulse_us(controls.pitch_servo_deg),
                  servo_pulse_us(controls.roll_servo_deg),
                  servo_pulse_us(controls.tilt_servo_deg),
                  controls.mode == MODE_AUTOPILOT);
}

int main(void)
{
    haptic_init(&controls);
    if (!board_init()) {
        /* If the clock cannot start, PWM timing is untrustworthy. Do not run. */
        __disable_irq();
        for (;;) { __WFI(); }
    }
    button_init(&mode_button, board_button(), board_millis());
    button_ready = true;
    haptic_step(&controls, 0, false); /* Neutral/AUTOPILOT until fresh data. */
    apply_outputs();
    board_log("HAPTIC DIAGNOSTIC v3 - automatic I2C recovery\r\n");
    board_log("BOOT OK. Checking sensor; PA12 is the external blue button.\r\n");

    bool sensor_ready = false;
    uint32_t last_sample = board_millis() - 20U;
    uint32_t last_retry = board_millis() - 1000U;
    uint32_t last_log = board_millis() - 1000U;
    for (;;) {
        const uint32_t now = board_millis();
        if ((uint32_t)(now - last_sample) < 20U) {
            __WFI();
            continue;
        }
        last_sample = now;
        /* A failed sensor is retried at1Hz while neutral PWM continues. This
         * intentionally does not spin indefinitely on NACK/stuck-bus errors. */
        if (!sensor_ready && (uint32_t)(now - last_retry) >= 1000U) {
            last_retry = now;
            sensor_ready = mpu6050_init();
            board_log(sensor_ready ? "MPU INIT OK\r\n" : "MPU INIT FAILED\r\n");
            /* Events during reset/warmup are discarded rather than deferred. */
            (void)take_button_event();
        }
        int16_t ax = 0, ay = 0, az = 0;
        const bool pressed = take_button_event();
        if (pressed) { board_log("BUTTON PRESS DETECTED\r\n"); }
        if (sensor_ready && mpu6050_read(&ax, &ay, &az) &&
            angles_from_accel(ax, ay, az, &measured_angles)) {
            haptic_step(&controls, &measured_angles, pressed);
        } else {
            sensor_ready = false;
            haptic_step(&controls, 0, false);
        }
        apply_outputs();
        if ((uint32_t)(board_millis() - last_log) >= 1000U) {
            last_log = board_millis();
            board_log("STATUS ms="); board_log_int((int32_t)last_log);
            board_log(" button="); board_log_int(board_button() ? 1 : 0);
            if (controls.fault) {
                board_log(" SENSOR ERROR: holding neutral/AUTOPILOT\r\n");
            } else {
                board_log(" SENSOR OK raw="); board_log_int(ax);
                board_log(","); board_log_int(ay); board_log(","); board_log_int(az);
                board_log(" pitch="); board_log_int((int32_t)measured_angles.pitch_deg);
                board_log(" roll="); board_log_int((int32_t)measured_angles.roll_deg);
                board_log(" tilt="); board_log_int((int32_t)measured_angles.tilt_deg);
                board_log(controls.mode == MODE_MANUAL ? " MANUAL\r\n" : " AUTOPILOT\r\n");
            }
        }
    }
}
