#ifndef BOARD_H
#define BOARD_H

/* Board I/O for the Nucleo-C031C6 assignment pin allocation. */
#include <stdbool.h>
#include <stdint.h>

bool board_init(void);
uint32_t board_millis(void);
void board_tick(void);
bool board_button(void);
void board_outputs(uint16_t pitch_us, uint16_t roll_us, uint16_t tilt_us,
                   bool autopilot);
bool mpu6050_init(void);
bool mpu6050_read(int16_t *x, int16_t *y, int16_t *z);

/* Temporary diagnostics on USART1 PA9, connected to Wokwi Serial Monitor. */
void board_log(const char *text);
void board_log_hex(uint32_t value);
void board_log_int(int32_t value);

#endif
