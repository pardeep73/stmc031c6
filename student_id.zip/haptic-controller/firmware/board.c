/* Generated with OpenAI Codex; see README.md for attribution.
 * Direct-register board support. Peripheral definitions are ST's CMSIS headers.
 * No HAL runtime, heap, RTOS, or UART connection is required. */
#include "board.h"
#include "stm32c031xx.h"

#define CPU_HZ 48000000U
#define MPU_ADDRESS (0x68U << 1U)
#define I2C_ERRORS (I2C_ISR_NACKF | I2C_ISR_BERR | I2C_ISR_ARLO | I2C_ISR_OVR)
#define I2C_CLEAR (I2C_ICR_NACKCF | I2C_ICR_STOPCF | I2C_ICR_BERRCF | \
                   I2C_ICR_ARLOCF | I2C_ICR_OVRCF)

uint32_t SystemCoreClock = CPU_HZ;
static volatile uint32_t milliseconds;
static const char *i2c_phase = "idle";
static bool stop_start_reads;
static uint32_t cr2_before_start, cr2_requested;

/* Diagnostic writes have a finite spin budget, including if the UART is absent.
 * Keep these out of SysTick: debounce and timeouts must remain responsive. */
void board_log(const char *text)
{
    while (*text != '\0') {
        uint32_t budget = 100000U;
        while ((USART1->ISR & USART_ISR_TXE_TXFNF) == 0U) {
            if (--budget == 0U) { return; }
        }
        USART1->TDR = (uint8_t)*text++;
    }
}

void board_log_hex(uint32_t value)
{
    static const char digits[] = "0123456789ABCDEF";
    char output[11] = "0x00000000";
    for (unsigned i = 0; i < 8U; ++i) {
        output[9U - i] = digits[value & 15U];
        value >>= 4U;
    }
    board_log(output);
}

void board_log_int(int32_t value)
{
    char output[12];
    unsigned at = sizeof(output) - 1U;
    const bool negative = value < 0;
    uint32_t magnitude = negative ? 0U - (uint32_t)value : (uint32_t)value;
    output[at] = '\0';
    do {
        output[--at] = (char)('0' + magnitude % 10U);
        magnitude /= 10U;
    } while (magnitude != 0U);
    if (negative) { output[--at] = '-'; }
    board_log(&output[at]);
}

static void log_i2c_failure(const char *reason, uint32_t status, uint32_t wanted)
{
    board_log("I2C "); board_log(reason); board_log(" at "); board_log(i2c_phase);
    board_log(" ISR="); board_log_hex(status);
    board_log(" waiting_for="); board_log_hex(wanted);
    board_log(" CR2="); board_log_hex(I2C1->CR2);
    board_log(" previous_CR2="); board_log_hex(cr2_before_start);
    board_log(" requested_CR2="); board_log_hex(cr2_requested);
    board_log("\r\n");
}

uint32_t board_millis(void) { return milliseconds; }
void board_tick(void) { ++milliseconds; }
bool board_button(void) { return (GPIOA->IDR & (1U << 12U)) != 0U; }

/* Only used with interrupts enabled: SysTick provides wrap-safe deadlines. */
static void delay_ms(uint32_t duration)
{
    const uint32_t start = board_millis();
    while ((uint32_t)(board_millis() - start) < duration) {
        __WFI();
    }
}

static void pin_mode(GPIO_TypeDef *port, unsigned pin, unsigned mode)
{
    const unsigned shift = 2U * pin;
    port->MODER = (port->MODER & ~(3UL << shift)) | ((uint32_t)mode << shift);
}

static void pin_af(GPIO_TypeDef *port, unsigned pin, unsigned af)
{
    const unsigned shift = (pin & 7U) * 4U;
    port->AFR[pin / 8U] = (port->AFR[pin / 8U] & ~(15UL << shift)) |
                          ((uint32_t)af << shift);
    pin_mode(port, pin, 2U);
}

static void i2c_enable(void)
{
    /* Both buses run at 48 MHz. Analog filter on, digital filter off.
     * PRESC=0, SCLDEL=11, SDADEL=4, SCLH=39, SCLL=79.
     * The programmed SCL high/low intervals sum to 2.5 us. Synchronizer,
     * analog filter and line rise/fall delays make the actual rate <400 kHz.
     * Fast-mode timing assumes rise <=120 ns, fall <=25 ns: external 3.3-V
     * pull-ups are required; verify the waveform on physical hardware. */
    RCC->APBRSTR1 |= RCC_APBRSTR1_I2C1RST;
    RCC->APBRSTR1 &= ~RCC_APBRSTR1_I2C1RST;
    I2C1->TIMINGR = 0x00B4274FU;
    I2C1->ICR = I2C_CLEAR;
    I2C1->CR1 = I2C_CR1_PE;
}

bool board_init(void)
{
    /* Reset starts with HSI48 divided by four. Increase Flash latency before
     * clearing HSIDIV, then explicitly select HSI and undivided AHB/APB. */
    FLASH->ACR = FLASH_ACR_LATENCY_0 | FLASH_ACR_PRFTEN;
    RCC->CR |= RCC_CR_HSION;
    uint32_t timeout = CPU_HZ;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0U) {
        if (--timeout == 0U) { return false; }
    }
    RCC->CR &= ~RCC_CR_HSIDIV;
    RCC->CFGR &= ~(RCC_CFGR_SW | RCC_CFGR_HPRE | RCC_CFGR_PPRE);
    timeout = CPU_HZ;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) {
        if (--timeout == 0U) { return false; }
    }
    RCC->IOPENR |= RCC_IOPENR_GPIOAEN | RCC_IOPENR_GPIOBEN;
    RCC->APBENR1 |= RCC_APBENR1_TIM3EN | RCC_APBENR1_I2C1EN;
    (void)RCC->IOPENR; /* Complete peripheral clock writes before GPIO access. */

    /* External LEDs: active high. PA12 is an external active-high button. */
    GPIOA->BSRR = (1U << (2U + 16U));
    GPIOB->BSRR = (1U << (11U + 16U));
    pin_mode(GPIOA, 2U, 1U);
    pin_mode(GPIOB, 11U, 1U);
    GPIOA->OTYPER &= ~(1U << 2U);
    GPIOB->OTYPER &= ~(1U << 11U);
    GPIOA->PUPDR &= ~(3UL << 4U);
    GPIOB->PUPDR &= ~(3UL << 22U);
    pin_mode(GPIOA, 12U, 0U);
    GPIOA->PUPDR = (GPIOA->PUPDR & ~(3UL << 24U)) | (2UL << 24U);

    /* ST's per-pin alternate-function table: TIM3 is AF1 on these pins. */
    pin_af(GPIOB, 4U, 1U);
    pin_af(GPIOB, 5U, 1U);
    pin_af(GPIOB, 0U, 1U);
    GPIOB->OTYPER &= ~((1U << 4U) | (1U << 5U) | 1U);
    GPIOB->PUPDR &= ~((3UL << 8U) | (3UL << 10U) | 3U);
    TIM3->CR1 = 0U;
    TIM3->PSC = 47U;   /* 48 MHz / 48 = 1 MHz: each counter tick is 1 us. */
    TIM3->ARR = 19999U; /* 20000 ticks = 20 ms = 50 Hz. */
    TIM3->CCR1 = 1500U; /* PB4: roll neutral at 90 degrees. */
    TIM3->CCR2 = 1500U; /* PB5: pitch neutral at 90 degrees. */
    TIM3->CCR3 = 1000U; /* PB0: tilt neutral at 0 degrees. */
    TIM3->CCMR1 = TIM_CCMR1_OC1PE | (6UL << TIM_CCMR1_OC1M_Pos) |
                   TIM_CCMR1_OC2PE | (6UL << TIM_CCMR1_OC2M_Pos);
    TIM3->CCMR2 = TIM_CCMR2_OC3PE | (6UL << TIM_CCMR2_OC3M_Pos);
    TIM3->CCER = TIM_CCER_CC1E | TIM_CCER_CC2E | TIM_CCER_CC3E;
    TIM3->EGR = TIM_EGR_UG; /* Load PSC, ARR and all initial compare values. */
    TIM3->SR = 0U;
    TIM3->CR1 = TIM_CR1_ARPE | TIM_CR1_CEN;

    /* I2C PB8/PB9 are AF6, open drain. Internal pulls remain off. */
    pin_af(GPIOB, 8U, 6U);
    pin_af(GPIOB, 9U, 6U);
    GPIOB->OTYPER |= (1U << 8U) | (1U << 9U);
    GPIOB->OSPEEDR |= (3UL << 16U) | (3UL << 18U);
    GPIOB->PUPDR &= ~((3UL << 16U) | (3UL << 18U));
    RCC->CCIPR &= ~RCC_CCIPR_I2C1SEL; /* I2C kernel clock = PCLK =48 MHz. */
    i2c_enable();
    /* PA9 is otherwise unused by the assignment. ST maps USART1_TX to AF1. */
    RCC->APBENR2 |= RCC_APBENR2_USART1EN;
    RCC->CCIPR &= ~RCC_CCIPR_USART1SEL;
    (void)RCC->APBENR2;
    pin_af(GPIOA, 9U, 1U);
    GPIOA->OTYPER &= ~(1U << 9U);
    USART1->CR1 = 0U;
    USART1->BRR = (CPU_HZ + 57600U) / 115200U;
    USART1->CR1 = USART_CR1_TE | USART_CR1_UE;
    return SysTick_Config(CPU_HZ / 1000U) == 0U;
}

void board_outputs(uint16_t pitch_us, uint16_t roll_us, uint16_t tilt_us,
                   bool autopilot)
{
    /* Preload registers apply together at the next timer update event. */
    const uint32_t primask = __get_PRIMASK();
    __disable_irq();
    TIM3->CR1 |= TIM_CR1_UDIS; /* Prevent partial preload latching mid-write. */
    TIM3->CCR1 = roll_us;
    TIM3->CCR2 = pitch_us;
    TIM3->CCR3 = tilt_us;
    TIM3->CR1 &= ~TIM_CR1_UDIS;
    __set_PRIMASK(primask);
    GPIOA->BSRR = 1UL << (autopilot ? 2U : 18U);
    GPIOB->BSRR = 1UL << (autopilot ? 27U : 11U);
}

static bool i2c_wait(uint32_t flag)
{
    const uint32_t start = board_millis();
    for (;;) {
        const uint32_t status = I2C1->ISR;
        if ((status & I2C_ERRORS) != 0U) {
            log_i2c_failure("error", status, flag); return false;
        }
        if ((status & flag) != 0U) { return true; }
        if ((uint32_t)(board_millis() - start) >= 5U) {
            log_i2c_failure("timeout", status, flag); return false;
        }
    }
}

static bool i2c_idle(void)
{
    const uint32_t start = board_millis();
    while ((I2C1->ISR & I2C_ISR_BUSY) != 0U) {
        if ((uint32_t)(board_millis() - start) >= 5U) {
            log_i2c_failure("bus busy", I2C1->ISR, 0U); return false;
        }
    }
    I2C1->ICR = I2C_CLEAR;
    return true;
}

/* Failure never returns stale register contents. Reset the peripheral to clear
 * its state. If a slave holds the wires low, future attempts also time out:
 * external wiring/power must be repaired before the device can recover. */
static bool i2c_fail(void)
{
    I2C1->CR2 |= I2C_CR2_STOP;
    i2c_enable();
    return false;
}

/* Configure direction/length before requesting START. This is valid on the MCU
 * and gives models a distinct START transition even if they retain START in
 * CR2 after the preceding phase. No received data or status flags are invented. */
static void i2c_start(unsigned length, bool read, bool autoend)
{
    const uint32_t config = MPU_ADDRESS |
        ((uint32_t)length << I2C_CR2_NBYTES_Pos) |
        (read ? I2C_CR2_RD_WRN : 0U) | (autoend ? I2C_CR2_AUTOEND : 0U);
    cr2_before_start = I2C1->CR2;
    cr2_requested = config | I2C_CR2_START;
    I2C1->CR2 = config;
    __DSB();
    I2C1->CR2 = cr2_requested;
}

static bool mpu_write(uint8_t reg, uint8_t value)
{
    i2c_phase = "write idle";
    if (!i2c_idle()) { return i2c_fail(); }
    i2c_start(2U, false, true);
    i2c_phase = "write register pointer";
    if (!i2c_wait(I2C_ISR_TXIS)) { return i2c_fail(); }
    I2C1->TXDR = reg;
    i2c_phase = "write register value";
    if (!i2c_wait(I2C_ISR_TXIS)) { return i2c_fail(); }
    I2C1->TXDR = value;
    i2c_phase = "write STOP";
    if (!i2c_wait(I2C_ISR_STOPF)) { return i2c_fail(); }
    I2C1->ICR = I2C_ICR_STOPCF;
    return true;
}

static bool mpu_read(uint8_t reg, uint8_t *data, unsigned length)
{
    i2c_phase = "read idle";
    if (!i2c_idle()) { return i2c_fail(); }
    i2c_start(1U, false, stop_start_reads);
    i2c_phase = "read register pointer";
    if (!i2c_wait(I2C_ISR_TXIS)) { return i2c_fail(); }
    I2C1->TXDR = reg;
    i2c_phase = stop_start_reads ? "register pointer STOP" : "read repeated START";
    if (!i2c_wait(stop_start_reads ? I2C_ISR_STOPF : I2C_ISR_TC)) {
        return i2c_fail();
    }
    if (stop_start_reads) {
        /* The MPU retains its register pointer across STOP. This alternative
         * uses a fresh addressed read and still receives the six axes bytes in
         * one burst; another I2C master must not modify the pointer meanwhile. */
        I2C1->ICR = I2C_ICR_STOPCF;
        if (!i2c_idle()) { return i2c_fail(); }
    }
    i2c_start(length, true, true);
    i2c_phase = "read data byte";
    for (unsigned i = 0U; i < length; ++i) {
        if (!i2c_wait(I2C_ISR_RXNE)) { return i2c_fail(); }
        data[i] = (uint8_t)I2C1->RXDR;
    }
    i2c_phase = "read STOP";
    if (!i2c_wait(I2C_ISR_STOPF)) { return i2c_fail(); }
    I2C1->ICR = I2C_ICR_STOPCF;
    return true;
}

bool mpu6050_init(void)
{
    uint8_t who = 0U;
    i2c_enable();
    board_log("MPU: reading identity\r\n");
    if (!mpu_read(0x75U, &who, 1U)) {
        if (stop_start_reads) { return false; }
        board_log("MPU: retrying identity using STOP then fresh START\r\n");
        stop_start_reads = true;
        if (!mpu_read(0x75U, &who, 1U)) { return false; }
    }
    board_log("MPU: WHO_AM_I="); board_log_hex(who); board_log("\r\n");
    if (who != 0x68U) { return false; }
    board_log(stop_start_reads ? "MPU: using STOP/START reads\r\n" :
                                  "MPU: using repeated START reads\r\n");
    board_log("MPU: resetting\r\n");
    if (!mpu_write(0x6BU, 0x80U)) { return false; } /* Device reset. */
    delay_ms(100U);
    board_log("MPU: waking\r\n");
    if (!mpu_write(0x6BU, 0x01U)) { return false; } /* Wake, PLL X-gyro. */
    delay_ms(10U);
    board_log("MPU: setting range and sample rate\r\n");
    /* DLPF=3, 1 kHz internal sample rate divided by20 ->50Hz; ±2g range. */
    return mpu_write(0x1AU, 0x03U) && mpu_write(0x19U, 19U) &&
           mpu_write(0x1CU, 0U);
}

bool mpu6050_read(int16_t *x, int16_t *y, int16_t *z)
{
    uint8_t bytes[6];
    if (!mpu_read(0x3BU, bytes, 6U)) { return false; }
    /* Big-endian sensor values -> signed two's-complement acceleration. */
    *x = (int16_t)((uint16_t)((uint16_t)bytes[0] << 8U) | bytes[1]);
    *y = (int16_t)((uint16_t)((uint16_t)bytes[2] << 8U) | bytes[3]);
    *z = (int16_t)((uint16_t)((uint16_t)bytes[4] << 8U) | bytes[5]);
    return true;
}
