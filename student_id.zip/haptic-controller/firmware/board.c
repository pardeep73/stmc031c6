/* Generated with OpenAI Codex; see README.md for attribution.
 * Direct-register board support. Peripheral definitions are ST's CMSIS headers.
 * No HAL runtime, heap, RTOS, or UART connection is required. */
#include "board.h"
#include "stm32c031xx.h"

#define CPU_HZ 48000000U
#define MPU_ADDRESS (0x68U << 1U)
#define I2C_ERRORS (I2C_ISR_NACKF | I2C_ISR_BERR | I2C_ISR_ARLO | I2C_ISR_OVR)
#define I2C_CLEAR (I2C_ICR_NACKCF | I2C_ICR_STOPCF | I2C_ICR_BERRCF | \
                   I2C_ICR_ARLOCF | I2C_ICR_OVRCF)

uint32_t SystemCoreClock = CPU_HZ;
static volatile uint32_t milliseconds;

uint32_t board_millis(void) { return milliseconds; }
void board_tick(void) { ++milliseconds; }
bool board_button(void) { return (GPIOA->IDR & (1U << 12U)) != 0U; }

/* Only used with interrupts enabled: SysTick provides wrap-safe deadlines. */
static void delay_ms(uint32_t duration)
{
    const uint32_t start = board_millis();
    while ((uint32_t)(board_millis() - start) < duration) {
        __WFI();
    }
}

static void pin_mode(GPIO_TypeDef *port, unsigned pin, unsigned mode)
{
    const unsigned shift = 2U * pin;
    port->MODER = (port->MODER & ~(3UL << shift)) | ((uint32_t)mode << shift);
}

static void pin_af(GPIO_TypeDef *port, unsigned pin, unsigned af)
{
    const unsigned shift = (pin & 7U) * 4U;
    port->AFR[pin / 8U] = (port->AFR[pin / 8U] & ~(15UL << shift)) |
                          ((uint32_t)af << shift);
    pin_mode(port, pin, 2U);
}

static void i2c_enable(void)
{
    /* Both buses run at 48 MHz. Analog filter on, digital filter off.
     * PRESC=0, SCLDEL=11, SDADEL=4, SCLH=39, SCLL=79.
     * The programmed SCL high/low intervals sum to 2.5 us. Synchronizer,
     * analog filter and line rise/fall delays make the actual rate <400 kHz.
     * Fast-mode timing assumes rise <=120 ns, fall <=25 ns: external 3.3-V
     * pull-ups are required; verify the waveform on physical hardware. */
    RCC->APBRSTR1 |= RCC_APBRSTR1_I2C1RST;
    RCC->APBRSTR1 &= ~RCC_APBRSTR1_I2C1RST;
    I2C1->TIMINGR = 0x00B4274FU;
    I2C1->ICR = I2C_CLEAR;
    I2C1->CR1 = I2C_CR1_PE;
}

bool board_init(void)
{
    /* Reset starts with HSI48 divided by four. Increase Flash latency before
     * clearing HSIDIV, then explicitly select HSI and undivided AHB/APB. */
    FLASH->ACR = FLASH_ACR_LATENCY_0 | FLASH_ACR_PRFTEN;
    RCC->CR |= RCC_CR_HSION;
    uint32_t timeout = CPU_HZ;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0U) {
        if (--timeout == 0U) { return false; }
    }
    RCC->CR &= ~RCC_CR_HSIDIV;
    RCC->CFGR &= ~(RCC_CFGR_SW | RCC_CFGR_HPRE | RCC_CFGR_PPRE);
    timeout = CPU_HZ;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) {
        if (--timeout == 0U) { return false; }
    }
    RCC->IOPENR |= RCC_IOPENR_GPIOAEN | RCC_IOPENR_GPIOBEN;
    RCC->APBENR1 |= RCC_APBENR1_TIM3EN | RCC_APBENR1_I2C1EN;
    (void)RCC->IOPENR; /* Complete peripheral clock writes before GPIO access. */

    /* External LEDs: active high. PA12 is an external active-high button. */
    GPIOA->BSRR = (1U << (2U + 16U));
    GPIOB->BSRR = (1U << (11U + 16U));
    pin_mode(GPIOA, 2U, 1U);
    pin_mode(GPIOB, 11U, 1U);
    GPIOA->OTYPER &= ~(1U << 2U);
    GPIOB->OTYPER &= ~(1U << 11U);
    GPIOA->PUPDR &= ~(3UL << 4U);
    GPIOB->PUPDR &= ~(3UL << 22U);
    pin_mode(GPIOA, 12U, 0U);
    GPIOA->PUPDR = (GPIOA->PUPDR & ~(3UL << 24U)) | (2UL << 24U);

    /* ST's per-pin alternate-function table: TIM3 is AF1 on these pins. */
    pin_af(GPIOB, 4U, 1U);
    pin_af(GPIOB, 5U, 1U);
    pin_af(GPIOB, 0U, 1U);
    GPIOB->OTYPER &= ~((1U << 4U) | (1U << 5U) | 1U);
    GPIOB->PUPDR &= ~((3UL << 8U) | (3UL << 10U) | 3U);
    TIM3->CR1 = 0U;
    TIM3->PSC = 47U;   /* 48 MHz / 48 = 1 MHz: each counter tick is 1 us. */
    TIM3->ARR = 19999U; /* 20000 ticks = 20 ms = 50 Hz. */
    TIM3->CCR1 = 1500U; /* PB4: roll neutral at 90 degrees. */
    TIM3->CCR2 = 1500U; /* PB5: pitch neutral at 90 degrees. */
    TIM3->CCR3 = 1000U; /* PB0: tilt neutral at 0 degrees. */
    TIM3->CCMR1 = TIM_CCMR1_OC1PE | (6UL << TIM_CCMR1_OC1M_Pos) |
                   TIM_CCMR1_OC2PE | (6UL << TIM_CCMR1_OC2M_Pos);
    TIM3->CCMR2 = TIM_CCMR2_OC3PE | (6UL << TIM_CCMR2_OC3M_Pos);
    TIM3->CCER = TIM_CCER_CC1E | TIM_CCER_CC2E | TIM_CCER_CC3E;
    TIM3->EGR = TIM_EGR_UG; /* Load PSC, ARR and all initial compare values. */
    TIM3->SR = 0U;
    TIM3->CR1 = TIM_CR1_ARPE | TIM_CR1_CEN;

    /* I2C PB8/PB9 are AF6, open drain. Internal pulls remain off. */
    pin_af(GPIOB, 8U, 6U);
    pin_af(GPIOB, 9U, 6U);
    GPIOB->OTYPER |= (1U << 8U) | (1U << 9U);
    GPIOB->OSPEEDR |= (3UL << 16U) | (3UL << 18U);
    GPIOB->PUPDR &= ~((3UL << 16U) | (3UL << 18U));
    RCC->CCIPR &= ~RCC_CCIPR_I2C1SEL; /* I2C kernel clock = PCLK =48 MHz. */
    i2c_enable();
    return SysTick_Config(CPU_HZ / 1000U) == 0U;
}

void board_outputs(uint16_t pitch_us, uint16_t roll_us, uint16_t tilt_us,
                   bool autopilot)
{
    /* Preload registers apply together at the next timer update event. */
    const uint32_t primask = __get_PRIMASK();
    __disable_irq();
    TIM3->CR1 |= TIM_CR1_UDIS; /* Prevent partial preload latching mid-write. */
    TIM3->CCR1 = roll_us;
    TIM3->CCR2 = pitch_us;
    TIM3->CCR3 = tilt_us;
    TIM3->CR1 &= ~TIM_CR1_UDIS;
    __set_PRIMASK(primask);
    GPIOA->BSRR = 1UL << (autopilot ? 2U : 18U);
    GPIOB->BSRR = 1UL << (autopilot ? 27U : 11U);
}

static bool i2c_wait(uint32_t flag)
{
    const uint32_t start = board_millis();
    for (;;) {
        const uint32_t status = I2C1->ISR;
        if ((status & I2C_ERRORS) != 0U) { return false; }
        if ((status & flag) != 0U) { return true; }
        if ((uint32_t)(board_millis() - start) >= 5U) { return false; }
    }
}

static bool i2c_idle(void)
{
    const uint32_t start = board_millis();
    while ((I2C1->ISR & I2C_ISR_BUSY) != 0U) {
        if ((uint32_t)(board_millis() - start) >= 5U) { return false; }
    }
    I2C1->ICR = I2C_CLEAR;
    return true;
}

/* Failure never returns stale register contents. Reset the peripheral to clear
 * its state. If a slave holds the wires low, future attempts also time out:
 * external wiring/power must be repaired before the device can recover. */
static bool i2c_fail(void)
{
    I2C1->CR2 |= I2C_CR2_STOP;
    i2c_enable();
    return false;
}

static bool mpu_write(uint8_t reg, uint8_t value)
{
    if (!i2c_idle()) { return i2c_fail(); }
    I2C1->CR2 = MPU_ADDRESS | (2UL << I2C_CR2_NBYTES_Pos) |
                 I2C_CR2_AUTOEND | I2C_CR2_START;
    if (!i2c_wait(I2C_ISR_TXIS)) { return i2c_fail(); }
    I2C1->TXDR = reg;
    if (!i2c_wait(I2C_ISR_TXIS)) { return i2c_fail(); }
    I2C1->TXDR = value;
    if (!i2c_wait(I2C_ISR_STOPF)) { return i2c_fail(); }
    I2C1->ICR = I2C_ICR_STOPCF;
    return true;
}

static bool mpu_read(uint8_t reg, uint8_t *data, unsigned length)
{
    if (!i2c_idle()) { return i2c_fail(); }
    I2C1->CR2 = MPU_ADDRESS | (1UL << I2C_CR2_NBYTES_Pos) | I2C_CR2_START;
    if (!i2c_wait(I2C_ISR_TXIS)) { return i2c_fail(); }
    I2C1->TXDR = reg;
    if (!i2c_wait(I2C_ISR_TC)) { return i2c_fail(); }
    /* Repeated START: write register pointer, then receive a coherent burst. */
    I2C1->CR2 = MPU_ADDRESS | ((uint32_t)length << I2C_CR2_NBYTES_Pos) |
                 I2C_CR2_RD_WRN | I2C_CR2_AUTOEND | I2C_CR2_START;
    for (unsigned i = 0U; i < length; ++i) {
        if (!i2c_wait(I2C_ISR_RXNE)) { return i2c_fail(); }
        data[i] = (uint8_t)I2C1->RXDR;
    }
    if (!i2c_wait(I2C_ISR_STOPF)) { return i2c_fail(); }
    I2C1->ICR = I2C_ICR_STOPCF;
    return true;
}

bool mpu6050_init(void)
{
    uint8_t who = 0U;
    i2c_enable();
    if (!mpu_read(0x75U, &who, 1U) || who != 0x68U) { return false; }
    if (!mpu_write(0x6BU, 0x80U)) { return false; } /* Device reset. */
    delay_ms(100U);
    if (!mpu_write(0x6BU, 0x01U)) { return false; } /* Wake, PLL X-gyro. */
    delay_ms(10U);
    /* DLPF=3, 1 kHz internal sample rate divided by20 ->50Hz; ±2g range. */
    return mpu_write(0x1AU, 0x03U) && mpu_write(0x19U, 19U) &&
           mpu_write(0x1CU, 0U);
}

bool mpu6050_read(int16_t *x, int16_t *y, int16_t *z)
{
    uint8_t bytes[6];
    if (!mpu_read(0x3BU, bytes, 6U)) { return false; }
    /* Big-endian sensor values -> signed two's-complement acceleration. */
    *x = (int16_t)((uint16_t)((uint16_t)bytes[0] << 8U) | bytes[1]);
    *y = (int16_t)((uint16_t)((uint16_t)bytes[2] << 8U) | bytes[3]);
    *z = (int16_t)((uint16_t)((uint16_t)bytes[4] << 8U) | bytes[5]);
    return true;
}
