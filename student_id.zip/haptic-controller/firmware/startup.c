/* Generated with OpenAI Codex; see README.md for attribution.
 * Minimal Cortex-M0+ reset/vector startup; IRQ positions follow ST CMSIS. */
#include <stdint.h>
#include "stm32c031xx.h"

extern uint32_t _estack, _sidata, _sdata, _edata, _sbss, _ebss;
extern int main(void);
void Reset_Handler(void);
void Default_Handler(void);
void SysTick_Handler(void) __attribute__((weak, alias("Default_Handler")));

typedef union {
    uint32_t *stack;
    void (*handler)(void);
} vector_entry_t;
__attribute__((used, section(".isr_vector")))
const vector_entry_t vector_table[48] = {
    [0] = { .stack = &_estack },
    [1] = { .handler = Reset_Handler },
    [2] = { .handler = Default_Handler }, /* NMI. */
    [3] = { .handler = Default_Handler }, /* HardFault. */
    [11] = { .handler = Default_Handler }, /* SVCall. */
    [14] = { .handler = Default_Handler }, /* PendSV. */
    [15] = { .handler = SysTick_Handler },
    [16] = { .handler = Default_Handler }, /* WWDG. */
    [18] = { .handler = Default_Handler }, /* RTC. */
    [19] = { .handler = Default_Handler }, /* FLASH. */
    [20] = { .handler = Default_Handler }, /* RCC. */
    [21] = { .handler = Default_Handler }, /* EXTI0_1. */
    [22] = { .handler = Default_Handler }, /* EXTI2_3. */
    [23] = { .handler = Default_Handler }, /* EXTI4_15. */
    [25] = { .handler = Default_Handler }, /* DMA channel1. */
    [26] = { .handler = Default_Handler }, /* DMA channel2_3. */
    [27] = { .handler = Default_Handler }, /* DMAMUX. */
    [28] = { .handler = Default_Handler }, /* ADC. */
    [29] = { .handler = Default_Handler }, /* TIM1 break/update/etc. */
    [30] = { .handler = Default_Handler }, /* TIM1 CC. */
    [32] = { .handler = Default_Handler }, /* TIM3. */
    [35] = { .handler = Default_Handler }, /* TIM14. */
    [37] = { .handler = Default_Handler }, /* TIM16. */
    [38] = { .handler = Default_Handler }, /* TIM17. */
    [39] = { .handler = Default_Handler }, /* I2C1. */
    [41] = { .handler = Default_Handler }, /* SPI1. */
    [43] = { .handler = Default_Handler }, /* USART1. */
    [44] = { .handler = Default_Handler }  /* USART2. */
};

void Reset_Handler(void)
{
    /* STM32C031 has VTOR. Match ST's SystemInit by placing the vector base in
     * flash explicitly: a simulator need not supply the reset-address alias.
     * Set this before main enables SysTick, then synchronize exception fetches. */
    SCB->VTOR = (uint32_t)vector_table;
    __DSB();
    __ISB();
    /* C runtime initialization: copy initialized data and zero static data. */
    uint32_t *destination = &_sdata;
    const uint32_t *source = &_sidata;
    while (destination < &_edata) { *destination++ = *source++; }
    destination = &_sbss;
    while (destination < &_ebss) { *destination++ = 0U; }
    (void)main();
    for (;;) { }
}

void Default_Handler(void)
{
    /* Unexpected interrupts are a debugger-visible fail-stop. */
    for (;;) { }
}
