/* Generated with OpenAI Codex; see README.md for attribution.
 * GPIO I2C fallback. Actual SDA levels supply all ACKs and received bytes;
 * this backend never substitutes sample data or bypasses MPU identity checks. */
#include "soft_i2c.h"

#include <stddef.h>

#ifdef SOFT_I2C_TEST
/* Host tests model the wired-AND bus, slave protocol, and clock stretching. */
#include "soft_i2c_test_io.h"
#else
#include "board.h"
#include "stm32c031xx.h"

#define SCL_PIN (1UL << 8U)
#define SDA_PIN (1UL << 9U)

static void soft_i2c_io_configure(void)
{
    RCC->IOPENR |= RCC_IOPENR_GPIOBEN;
    (void)RCC->IOPENR;
    /* Set output latches high before selecting output mode. In open-drain
     * mode, HIGH releases a line: no output ever actively drives it high. */
    GPIOB->BSRR = SCL_PIN | SDA_PIN;
    GPIOB->OTYPER |= SCL_PIN | SDA_PIN;
    GPIOB->PUPDR &= ~((3UL << 16U) | (3UL << 18U));
    GPIOB->MODER = (GPIOB->MODER & ~((3UL << 16U) | (3UL << 18U))) |
                    (1UL << 16U) | (1UL << 18U);
}

static void soft_i2c_io_scl(bool release)
{
    GPIOB->BSRR = release ? SCL_PIN : SCL_PIN << 16U;
    __DSB();
}

static void soft_i2c_io_sda(bool release)
{
    GPIOB->BSRR = release ? SDA_PIN : SDA_PIN << 16U;
    __DSB();
}

static bool soft_i2c_io_read_scl(void)
{
    return (GPIOB->IDR & SCL_PIN) != 0U;
}

static bool soft_i2c_io_read_sda(void)
{
    return (GPIOB->IDR & SDA_PIN) != 0U;
}

static uint32_t soft_i2c_io_millis(void) { return board_millis(); }

static void soft_i2c_io_delay(void)
{
    /* At the configured 48 MHz, this finite 80-iteration NOP/branch loop gives
     * several microseconds per half-cycle, aiming below 100 kHz. Interrupts
     * may lengthen it. This is a conservative software timing assumption,
     * not a measured frequency: verify waveforms on physical hardware. */
    for (unsigned delay = 0U; delay < 80U; ++delay) { __NOP(); }
}
#endif

/* A time limit plus finite spin budget also handles an unavailable tick. */
static bool scl_high(void)
{
    const uint32_t start = soft_i2c_io_millis();
    uint32_t budget = 100000U;
    soft_i2c_io_scl(true);
    while (!soft_i2c_io_read_scl()) {
        if ((uint32_t)(soft_i2c_io_millis() - start) >= 5U ||
            --budget == 0U) { return false; }
    }
    return true;
}

static bool stop(void)
{
    /* Generate STOP when possible, but release both outputs even if a slave
     * holds SCL low. An externally stuck bus is reported, never waited forever. */
    soft_i2c_io_scl(false);
    soft_i2c_io_sda(false);
    soft_i2c_io_delay();
    const bool clock_ok = scl_high();
    soft_i2c_io_delay();
    soft_i2c_io_sda(true);
    soft_i2c_io_delay();
    return clock_ok && soft_i2c_io_read_scl() && soft_i2c_io_read_sda();
}

static bool start(void)
{
    /* Also valid as a repeated START after a transmitted register pointer. */
    soft_i2c_io_sda(true);
    soft_i2c_io_delay();
    if (!scl_high()) { return false; }
    soft_i2c_io_delay();
    if (!soft_i2c_io_read_sda()) { return false; }
    soft_i2c_io_sda(false);
    soft_i2c_io_delay();
    soft_i2c_io_scl(false);
    return true;
}

static bool write_bit(bool bit)
{
    soft_i2c_io_sda(bit);
    soft_i2c_io_delay();
    if (!scl_high()) { return false; }
    soft_i2c_io_delay();
    /* A released SDA must actually be high outside the slave ACK slot. */
    const bool level_ok = !bit || soft_i2c_io_read_sda();
    soft_i2c_io_scl(false);
    return level_ok;
}

static bool read_bit(bool *bit)
{
    soft_i2c_io_sda(true);
    soft_i2c_io_delay();
    if (!scl_high()) { return false; }
    soft_i2c_io_delay();
    *bit = soft_i2c_io_read_sda();
    soft_i2c_io_scl(false);
    return true;
}

static bool write_byte(uint8_t byte)
{
    for (unsigned bit = 0U; bit < 8U; ++bit) {
        if (!write_bit((byte & 0x80U) != 0U)) { return false; }
        byte = (uint8_t)(byte << 1U);
    }
    bool nack = true;
    return read_bit(&nack) && !nack;
}

static bool read_byte(uint8_t *byte, bool more)
{
    uint8_t received = 0U;
    for (unsigned bit = 0U; bit < 8U; ++bit) {
        bool value = false;
        if (!read_bit(&value)) { return false; }
        received = (uint8_t)((received << 1U) | (value ? 1U : 0U));
    }
    /* More bytes: drive ACK low. Final byte: leave SDA high for NACK. */
    if (!write_bit(!more)) { return false; }
    soft_i2c_io_sda(true);
    *byte = received;
    return true;
}

bool soft_i2c_init(void)
{
    soft_i2c_io_configure();
    soft_i2c_io_sda(true);
    if (!scl_high()) {
        soft_i2c_io_sda(true);
        return false;
    }
    if (soft_i2c_io_read_sda()) { return true; }
    /* At most nine startup clocks let a slave finish an interrupted byte. */
    for (unsigned pulse = 0U; pulse < 9U && !soft_i2c_io_read_sda(); ++pulse) {
        soft_i2c_io_scl(false);
        soft_i2c_io_delay();
        if (!scl_high()) {
            soft_i2c_io_sda(true);
            return false;
        }
        soft_i2c_io_delay();
    }
    return stop();
}

bool soft_i2c_write_reg(uint8_t addr, uint8_t reg, uint8_t value)
{
    if (addr > 0x7FU) { return false; }
    const bool transferred = start() && write_byte((uint8_t)(addr << 1U)) &&
                              write_byte(reg) && write_byte(value);
    const bool stopped = stop();
    return transferred && stopped;
}

bool soft_i2c_read_regs(uint8_t addr, uint8_t reg, uint8_t *data, unsigned length)
{
    if (addr > 0x7FU || data == NULL || length == 0U ||
        length > SOFT_I2C_MAX_READ) { return false; }
    uint8_t received[SOFT_I2C_MAX_READ];
    bool transferred = start() && write_byte((uint8_t)(addr << 1U)) &&
                        write_byte(reg) && start() &&
                        write_byte((uint8_t)((addr << 1U) | 1U));
    for (unsigned i = 0U; i < length && transferred; ++i) {
        transferred = read_byte(&received[i], i + 1U < length);
    }
    const bool stopped = stop();
    if (!transferred || !stopped) { return false; }
    for (unsigned i = 0U; i < length; ++i) { data[i] = received[i]; }
    return true;
}
