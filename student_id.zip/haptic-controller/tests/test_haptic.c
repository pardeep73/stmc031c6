#include "haptic.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

/* Host checks use the Assignment 2 equations, entry thresholds and release-only
 * deadbands. They validate the portable controller, not MCU electrical timing. */
static unsigned checks;

#define CHECK(condition) do { \
    ++checks; \
    if (!(condition)) { \
        fprintf(stderr, "%s:%d: failed: %s\n", __FILE__, __LINE__, #condition); \
        exit(EXIT_FAILURE); \
    } \
} while (0)

static void near(float actual, float expected, float tolerance)
{
    ++checks;
    if (!isfinite(actual) || fabsf(actual - expected) > tolerance) {
        fprintf(stderr, "Expected %.6f +/- %.6f; got %.6f\n",
                (double)expected, (double)tolerance, (double)actual);
        exit(EXIT_FAILURE);
    }
}

static angles_t angles(float pitch, float roll)
{
    const angles_t result = {pitch, roll, sqrtf(pitch * pitch + roll * roll)};
    return result;
}

/* Invert the assignment's orientation equations for a unit gravity vector.
 * These represent physically consistent test cases, not unrelated axis inputs. */
static angles_t gravity_sample(float pitch, float roll)
{
    const float to_rad = 0.017453292519943295f;
    const float theta = pitch * to_rad;
    const float phi = roll * to_rad;
    const float ax = -sinf(theta);
    const float ay = cosf(theta) * sinf(phi);
    const float az = cosf(theta) * cosf(phi);
    const int16_t raw_x = (int16_t)lroundf(ax * 16384.0f);
    const int16_t raw_y = (int16_t)lroundf(ay * 16384.0f);
    const int16_t raw_z = (int16_t)lroundf(az * 16384.0f);
    const float norm = sqrtf((float)raw_x * raw_x + (float)raw_y * raw_y +
                            (float)raw_z * raw_z) / 16384.0f;
    near(norm, 1.0f, 0.0001f);
    angles_t actual;
    CHECK(angles_from_accel(raw_x, raw_y, raw_z, &actual));
    near(actual.pitch_deg, pitch, 0.02f);
    near(actual.roll_deg, roll, 0.02f);
    near(actual.tilt_deg, hypotf(pitch, roll), 0.03f);
    return actual;
}

static void test_angles(void)
{
    angles_t value;
    CHECK(!angles_from_accel(0, 0, 0, &value));
    CHECK(!angles_from_accel(0, 0, 16384, NULL));
    CHECK(angles_from_accel(0, 0, 16384, &value));
    near(value.pitch_deg, 0.0f, 0.001f);
    near(value.roll_deg, 0.0f, 0.001f);
    near(value.tilt_deg, 0.0f, 0.001f);
    CHECK(angles_from_accel(-16384, 0, 0, &value));
    near(value.pitch_deg, 90.0f, 0.001f);
    CHECK(angles_from_accel(16384, 0, 0, &value));
    near(value.pitch_deg, -90.0f, 0.001f);
    CHECK(angles_from_accel(0, 16384, 0, &value));
    near(value.roll_deg, 90.0f, 0.001f);
    CHECK(angles_from_accel(0, -16384, 0, &value));
    near(value.roll_deg, -90.0f, 0.001f);
    CHECK(angles_from_accel(0, 0, -16384, &value));
    near(fabsf(value.roll_deg), 180.0f, 0.001f);

    /* Four-quadrant roll must remain correct even when Z is negative. */
    for (int pitch = -75; pitch <= 75; pitch += 15) {
        for (int roll = -165; roll <= 165; roll += 15) {
            (void)gravity_sample((float)pitch, (float)roll);
        }
    }
    /* Common scaling cancels in atan2; no requirement to normalize in code. */
    angles_t scaled;
    CHECK(angles_from_accel(-8192, 4096, 4096, &value));
    CHECK(angles_from_accel(-16384, 8192, 8192, &scaled));
    near(scaled.pitch_deg, value.pitch_deg, 0.001f);
    near(scaled.roll_deg, value.roll_deg, 0.001f);
    near(scaled.tilt_deg, value.tilt_deg, 0.001f);
}

static void test_regions(void)
{
    const float thresholds[][2] = {{30.0f, 50.0f}, {20.0f, 70.0f}};
    for (unsigned i = 0; i < 2; ++i) {
        const float low = thresholds[i][0];
        const float high = thresholds[i][1];
        region_t state = REGION_FREE;
        CHECK(region_update(state, low - 0.01f, low, high) == REGION_FREE);
        state = region_update(state, low, low, high);
        CHECK(state == REGION_COMPLIANT);
        CHECK(region_update(state, low - 4.99f, low, high) == REGION_COMPLIANT);
        CHECK(region_update(state, low - 5.0f, low, high) == REGION_FREE);
        CHECK(region_update(state, high - 0.01f, low, high) == REGION_COMPLIANT);
        state = region_update(state, high, low, high);
        CHECK(state == REGION_CLAMP);
        CHECK(region_update(state, high - 4.99f, low, high) == REGION_CLAMP);
        state = region_update(state, high - 5.0f, low, high);
        CHECK(state == REGION_COMPLIANT);
        CHECK(region_update(state, low - 5.0f, low, high) == REGION_FREE);
        CHECK(region_update(REGION_FREE, high + 10.0f, low, high) == REGION_CLAMP);
        CHECK(region_update(REGION_CLAMP, 0.0f, low, high) == REGION_FREE);
        CHECK(region_update(REGION_CLAMP, low - 5.0f, low, high) == REGION_FREE);
        /* Noise inside either release band must not toggle the state. */
        state = REGION_COMPLIANT;
        for (unsigned sample = 0; sample < 100; ++sample) {
            state = region_update(state, low + (sample % 2 ? 0.5f : -0.5f), low, high);
            CHECK(state == REGION_COMPLIANT);
        }
        state = REGION_CLAMP;
        for (unsigned sample = 0; sample < 100; ++sample) {
            state = region_update(state, high + (sample % 2 ? 0.5f : -0.5f), low, high);
            CHECK(state == REGION_CLAMP);
        }
    }
}

static void expect_neutral_fault(const haptic_t *state)
{
    CHECK(state->fault);
    CHECK(state->mode == MODE_AUTOPILOT);
    CHECK(state->pitch_region == REGION_FREE);
    CHECK(state->roll_region == REGION_FREE);
    CHECK(state->tilt_region == REGION_FREE);
    near(state->pitch_servo_deg, 90.0f, 0.001f);
    near(state->roll_servo_deg, 90.0f, 0.001f);
    near(state->tilt_servo_deg, 0.0f, 0.001f);
}

static void test_servos(void)
{
    haptic_t state;
    haptic_init(&state);
    expect_neutral_fault(&state);
    angles_t value = angles(0.0f, 0.0f);
    haptic_step(&state, &value, false);
    CHECK(!state.fault);
    CHECK(state.mode == MODE_AUTOPILOT);
    near(state.pitch_servo_deg, 90.0f, 0.001f);
    near(state.roll_servo_deg, 90.0f, 0.001f);
    near(state.tilt_servo_deg, 0.0f, 0.001f);

    for (int sign = -1; sign <= 1; sign += 2) {
        haptic_init(&state);
        value = angles((float)sign * 40.0f, 0.0f);
        haptic_step(&state, &value, false);
        CHECK(state.pitch_region == REGION_COMPLIANT);
        CHECK(state.roll_region == REGION_FREE);
        CHECK(state.tilt_region == REGION_COMPLIANT);
        near(state.pitch_servo_deg, 90.0f + (float)sign * 40.0f, 0.001f);
        near(state.roll_servo_deg, 90.0f, 0.001f);
        near(state.tilt_servo_deg, 80.0f, 0.001f);
        value = angles((float)sign * 60.0f, 0.0f);
        haptic_step(&state, &value, false);
        CHECK(state.pitch_region == REGION_CLAMP);
        near(state.pitch_servo_deg, sign < 0 ? 40.0f : 140.0f, 0.001f);

        haptic_init(&state);
        value = angles(0.0f, (float)sign * 40.0f);
        haptic_step(&state, &value, false);
        CHECK(state.roll_region == REGION_COMPLIANT);
        near(state.pitch_servo_deg, 90.0f, 0.001f);
        near(state.roll_servo_deg, 90.0f + (float)sign * 40.0f, 0.001f);
        value = angles(0.0f, (float)sign * 160.0f);
        haptic_step(&state, &value, false);
        CHECK(!state.fault);
        CHECK(state.roll_region == REGION_CLAMP);
        near(state.roll_servo_deg, sign < 0 ? 40.0f : 140.0f, 0.001f);
        near(state.tilt_servo_deg, 140.0f, 0.001f);
    }

    /* Both individual axes remain free while the unified tilt warns. */
    haptic_init(&state);
    value = gravity_sample(15.0f, 15.0f);
    haptic_step(&state, &value, false);
    CHECK(state.pitch_region == REGION_FREE && state.roll_region == REGION_FREE);
    CHECK(state.tilt_region == REGION_COMPLIANT);
    near(state.pitch_servo_deg, 90.0f, 0.001f);
    near(state.roll_servo_deg, 90.0f, 0.001f);
    near(state.tilt_servo_deg, 42.4264f, 0.03f);

    /* Exact tilt entry/release levels use direct angles to avoid quantization. */
    haptic_init(&state);
    value = angles(20.0f, 0.0f);
    haptic_step(&state, &value, false);
    CHECK(state.tilt_region == REGION_COMPLIANT);
    near(state.tilt_servo_deg, 40.0f, 0.001f);
    value = angles(70.0f, 0.0f);
    haptic_step(&state, &value, false);
    CHECK(state.tilt_region == REGION_CLAMP);
    near(state.tilt_servo_deg, 140.0f, 0.001f);
    value = angles(65.01f, 0.0f);
    haptic_step(&state, &value, false);
    CHECK(state.tilt_region == REGION_CLAMP);
    value = angles(65.0f, 0.0f);
    haptic_step(&state, &value, false);
    CHECK(state.tilt_region == REGION_COMPLIANT);
    near(state.tilt_servo_deg, 130.0f, 0.001f);
    value = angles(15.0f, 0.0f);
    haptic_step(&state, &value, false);
    CHECK(state.tilt_region == REGION_FREE);
    near(state.tilt_servo_deg, 0.0f, 0.001f);
}

static void test_modes(void)
{
    haptic_t state;
    haptic_init(&state);
    angles_t value = angles(0.0f, 0.0f);
    haptic_step(&state, &value, true);
    CHECK(state.mode == MODE_MANUAL);
    haptic_step(&state, &value, false);
    CHECK(state.mode == MODE_MANUAL);
    haptic_step(&state, &value, true);
    CHECK(state.mode == MODE_AUTOPILOT);

    /* Unsafe events are discarded, including equality at the free boundary. */
    value = angles(30.0f, 0.0f);
    haptic_step(&state, &value, true);
    CHECK(state.mode == MODE_AUTOPILOT);
    value = angles(29.0f, 0.0f);
    haptic_step(&state, &value, true);
    CHECK(state.mode == MODE_AUTOPILOT);
    CHECK(state.pitch_region == REGION_COMPLIANT);
    value = angles(0.0f, 0.0f);
    haptic_step(&state, &value, false);
    CHECK(state.mode == MODE_AUTOPILOT);
    haptic_step(&state, &value, true);
    CHECK(state.mode == MODE_MANUAL);

    /* A genuine unit-gravity vector reaches both clamps with the actual
     * assignment equations: ax=-.8660, ay=.4330, az=.2500. */
    value = gravity_sample(60.0f, 60.0f);
    haptic_step(&state, &value, false);
    CHECK(state.pitch_region == REGION_CLAMP && state.roll_region == REGION_CLAMP);
    CHECK(state.mode == MODE_AUTOPILOT);
    near(state.pitch_servo_deg, 140.0f, 0.001f);
    near(state.roll_servo_deg, 140.0f, 0.001f);
    near(state.tilt_servo_deg, 140.0f, 0.001f);
    haptic_step(&state, &value, true);
    CHECK(state.mode == MODE_AUTOPILOT);

    value = angles(0.0f, 0.0f);
    haptic_step(&state, &value, false);
    CHECK(state.mode == MODE_AUTOPILOT);
    haptic_step(&state, &value, true);
    CHECK(state.mode == MODE_MANUAL);
    value = angles(-60.0f, 0.0f);
    haptic_step(&state, &value, false);
    CHECK(state.mode == MODE_MANUAL); /* One clamp alone does not engage. */
    haptic_step(&state, &value, true);
    CHECK(state.mode == MODE_AUTOPILOT); /* A manual-mode press always engages. */
}

static void test_faults(void)
{
    const angles_t invalid[] = {
        {NAN, 0.0f, 0.0f}, {0.0f, NAN, 0.0f}, {0.0f, 0.0f, NAN},
        {INFINITY, 0.0f, 0.0f}, {0.0f, -INFINITY, 0.0f}, {0.0f, 0.0f, INFINITY},
        {90.01f, 0.0f, 90.01f}, {-90.01f, 0.0f, 90.01f},
        {0.0f, 180.01f, 180.01f}, {0.0f, -180.01f, 180.01f},
        {0.0f, 0.0f, -0.01f}, {0.0f, 0.0f, 201.26f}
    };
    haptic_t state;
    const angles_t center = angles(0.0f, 0.0f);
    for (unsigned i = 0; i < sizeof(invalid) / sizeof(invalid[0]); ++i) {
        haptic_init(&state);
        haptic_step(&state, &center, true);
        CHECK(state.mode == MODE_MANUAL);
        haptic_step(&state, &invalid[i], true);
        expect_neutral_fault(&state);
        haptic_step(&state, &center, false);
        CHECK(!state.fault);
        CHECK(state.mode == MODE_AUTOPILOT);
    }
    haptic_step(&state, NULL, true);
    expect_neutral_fault(&state);
    const angles_t extreme = angles(90.0f, 180.0f);
    haptic_step(&state, &extreme, false);
    CHECK(!state.fault);
    CHECK(state.pitch_region == REGION_CLAMP && state.roll_region == REGION_CLAMP);
}

static void test_button(void)
{
    button_t button;
    button_init(&button, false, 0u);
    CHECK(!button_update(&button, false, 1u));
    CHECK(!button_update(&button, true, 10u));
    CHECK(!button_update(&button, false, 15u));
    CHECK(!button_update(&button, true, 20u));
    CHECK(!button_update(&button, true, 49u));
    CHECK(button_update(&button, true, 50u));
    CHECK(!button_update(&button, true, 51u));
    CHECK(!button_update(&button, true, 500u));
    CHECK(!button_update(&button, false, 510u));
    CHECK(!button_update(&button, true, 520u));
    CHECK(!button_update(&button, false, 530u));
    CHECK(!button_update(&button, false, 559u));
    CHECK(!button_update(&button, false, 560u)); /* Release is not a press. */
    CHECK(!button.stable);
    CHECK(!button_update(&button, true, 570u));
    CHECK(button_update(&button, true, 600u));

    /* A button held during boot requires release before generating an event. */
    button_init(&button, true, 0u);
    CHECK(!button_update(&button, true, 100u));
    CHECK(!button_update(&button, false, 110u));
    CHECK(!button_update(&button, false, 140u));
    CHECK(!button_update(&button, true, 150u));
    CHECK(button_update(&button, true, 180u));

    /* Timestamp arithmetic must remain valid across the 32-bit tick rollover. */
    button_init(&button, false, UINT32_MAX - 20u);
    CHECK(!button_update(&button, true, UINT32_MAX - 10u));
    CHECK(!button_update(&button, true, 18u));
    CHECK(button_update(&button, true, 19u));
    CHECK(!button_update(&button, true, 20u));
}

static void test_pwm(void)
{
    CHECK(servo_pulse_us(0.0f) == 1000u);
    CHECK(servo_pulse_us(90.0f) == 1500u);
    CHECK(servo_pulse_us(180.0f) == 2000u);
    CHECK(servo_pulse_us(40.0f) == 1222u);
    CHECK(servo_pulse_us(140.0f) == 1778u);
    CHECK(servo_pulse_us(-100.0f) == 1000u);
    CHECK(servo_pulse_us(250.0f) == 2000u);
    CHECK(servo_pulse_us(NAN) == 1500u);
    CHECK(servo_pulse_us(INFINITY) == 1500u);
    CHECK(servo_pulse_us(-INFINITY) == 1500u);
    uint16_t previous = servo_pulse_us(0.0f);
    for (unsigned i = 1; i <= 1800; ++i) {
        const float degrees = (float)i * 0.1f;
        const uint16_t pulse = servo_pulse_us(degrees);
        CHECK(pulse >= previous);
        CHECK(pulse >= 1000u && pulse <= 2000u);
        near((float)pulse, 1000.0f + degrees * (1000.0f / 180.0f), 0.51f);
        previous = pulse;
    }
}

int main(void)
{
    test_angles();
    test_regions();
    test_servos();
    test_modes();
    test_faults();
    test_button();
    test_pwm();
    printf("PASS: %u checks (angles, hysteresis, servos, FSM, faults, debounce, PWM)\n", checks);
    return EXIT_SUCCESS;
}
