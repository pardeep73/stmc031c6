#!/usr/bin/env python3
"""Exercise the actual sensor-initialization/recovery functions with fault injection.

Generated with OpenAI Codex; see README.md for attribution. This host integration
test extracts the functions from board.c unchanged, and mocks their transport
boundary. It tests recovery decisions, not STM32 registers or Wokwi behavior.
Python 3 and a native C compiler are required; no Python packages are needed.
"""
from pathlib import Path
import os
import re
import shlex
import subprocess
import tempfile


def function(source: str, name: str) -> str:
    """Extract a whole C function, ignoring braces in comments/string literals."""
    match = re.search(
        rf"^(?:static\s+)?bool\s+{re.escape(name)}\s*\([^)]*\)\s*\{{",
        source,
        re.MULTILINE,
    )
    if match is None:
        raise RuntimeError(f"Cannot locate actual board.c function {name}")
    depth = 1
    at = match.end()
    state = "code"
    while at < len(source):
        char = source[at]
        following = source[at : at + 2]
        if state == "code":
            if following in ("/*", "//"):
                state = "block" if following == "/*" else "line"
                at += 2
                continue
            if char in ("'", '"'):
                state = char
            elif char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    return source[match.start() : at + 1]
        elif state == "block" and following == "*/":
            state = "code"
            at += 2
            continue
        elif state == "line" and char == "\n":
            state = "code"
        elif state in ("'", '"'):
            if char == "\\":
                at += 2
                continue
            if char == state:
                state = "code"
        at += 1
    raise RuntimeError(f"Unterminated actual board.c function {name}")


PREFIX = r'''
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned checks;
#define CHECK(condition) do { ++checks; if (!(condition)) { \
    fprintf(stderr, "line %d: %s\n", __LINE__, #condition); exit(EXIT_FAILURE); \
} } while (0)

/* The mocked transport records actual initialization calls and supplies faults.
 * It does not reproduce the recovery algorithm that is under test. */
static bool gpio_i2c, stop_start_reads;
static bool read_ok, soft_init_ok, gpio_write_ok, soft_initialized;
static uint8_t hardware_identity, gpio_identity;
static unsigned fail_write, hardware_writes, gpio_writes, probes, soft_inits;
static uint32_t virtual_ms, configured_ms;
static bool configuration_complete;
static uint8_t hardware_regs[5], hardware_values[5], gpio_regs[5], gpio_values[5];
typedef struct { uint32_t CR1; } I2C_TypeDef;
static I2C_TypeDef peripheral;
#define I2C1 (&peripheral)
#define I2C_CR1_PE 1U

static void board_log(const char *text) { (void)text; }
static void board_log_hex(uint32_t value) { (void)value; }
static void delay_ms(uint32_t duration) { virtual_ms += duration; }
static void i2c_enable(void) { ++probes; }
static bool soft_i2c_init(void)
{
    ++soft_inits;
    CHECK((I2C1->CR1 & I2C_CR1_PE) == 0U);
    soft_initialized = soft_init_ok;
    return soft_init_ok;
}

static bool mpu_read(uint8_t reg, uint8_t *data, unsigned length)
{
    if (gpio_i2c) { CHECK(soft_initialized); }
    if (!read_ok) { return false; }
    for (unsigned i = 0; i < length; ++i) {
        data[i] = reg == 0x75U ?
            (gpio_i2c ? gpio_identity : hardware_identity) : (uint8_t)(i + 1U);
    }
    return true;
}

static bool mpu_write(uint8_t reg, uint8_t value)
{
    if (gpio_i2c) {
        CHECK(soft_initialized);
        CHECK(gpio_writes < 5U);
        gpio_regs[gpio_writes] = reg;
        gpio_values[gpio_writes++] = value;
        if (gpio_write_ok && reg == 0x1CU) {
            configuration_complete = true;
            configured_ms = virtual_ms;
        }
        return gpio_write_ok;
    }
    CHECK(hardware_writes < 5U);
    hardware_regs[hardware_writes] = reg;
    hardware_values[hardware_writes++] = value;
    if (hardware_writes != fail_write && reg == 0x1CU) {
        configuration_complete = true;
        configured_ms = virtual_ms;
    }
    return hardware_writes != fail_write;
}
'''

SUFFIX = r'''
static void reset(void)
{
    gpio_i2c = stop_start_reads = soft_initialized = false;
    read_ok = soft_init_ok = gpio_write_ok = true;
    hardware_identity = gpio_identity = 0x68U;
    fail_write = hardware_writes = gpio_writes = probes = soft_inits = 0U;
    virtual_ms = configured_ms = 0U;
    configuration_complete = false;
    I2C1->CR1 = I2C_CR1_PE;
    memset(hardware_regs, 0, sizeof(hardware_regs));
    memset(hardware_values, 0, sizeof(hardware_values));
    memset(gpio_regs, 0, sizeof(gpio_regs));
    memset(gpio_values, 0, sizeof(gpio_values));
}

int main(void)
{
    const uint8_t regs[5] = {0x6BU, 0x6BU, 0x1AU, 0x19U, 0x1CU};
    const uint8_t values[5] = {0x80U, 0x01U, 0x03U, 19U, 0x00U};

    reset();
    CHECK(mpu6050_init());
    CHECK(!gpio_i2c && probes == 1U && hardware_writes == 5U);
    CHECK(memcmp(hardware_regs, regs, sizeof(regs)) == 0);
    CHECK(memcmp(hardware_values, values, sizeof(values)) == 0);
    /* At 50 Hz allow at least two frames after final configuration. Otherwise
     * a legitimate startup-zero sample can cause a needless reset/retry loop. */
    CHECK(configuration_complete && virtual_ms - configured_ms >= 40U);

    /* Every configuration operation can fail after identity succeeds. A failure
     * must not enter the GPIO transport until the next initialization configures
     * those pins; successful identity alone must not pin us to a broken backend. */
    for (unsigned step = 1U; step <= 5U; ++step) {
        reset();
        fail_write = step;
        CHECK(!mpu6050_init());
        CHECK(hardware_writes == step);
        CHECK(memcmp(hardware_regs, regs, step) == 0);
        CHECK(memcmp(hardware_values, values, step) == 0);
        CHECK(gpio_i2c);
        CHECK(soft_inits == 0U && gpio_writes == 0U);
        CHECK(mpu6050_init());
        CHECK(probes == 1U && soft_inits == 1U && gpio_writes == 5U);
        CHECK(memcmp(gpio_regs, regs, sizeof(regs)) == 0);
        CHECK(memcmp(gpio_values, values, sizeof(values)) == 0);
        CHECK(configuration_complete && virtual_ms - configured_ms >= 40U);
    }

    reset();
    hardware_identity = gpio_identity = 0U;
    CHECK(!mpu6050_init());
    CHECK(gpio_i2c && soft_inits == 0U && hardware_writes == 0U);
    CHECK(!mpu6050_init());
    CHECK(gpio_i2c && soft_inits == 1U && gpio_writes == 0U);

    reset();
    hardware_identity = 0U;
    CHECK(!mpu6050_init());
    CHECK(gpio_i2c && gpio_writes == 0U);
    CHECK(mpu6050_init());
    CHECK(gpio_writes == 5U);
    CHECK(configuration_complete && virtual_ms - configured_ms >= 40U);

    reset();
    gpio_i2c = true;
    gpio_write_ok = false;
    CHECK(!mpu6050_init());
    CHECK(gpio_i2c && gpio_writes == 1U);
    CHECK(!stop_start_reads); /* Never silently switch back to hardware. */

    reset();
    gpio_i2c = true;
    soft_init_ok = false;
    CHECK(!mpu6050_init());
    CHECK(soft_inits == 1U && gpio_writes == 0U);

    reset();
    read_ok = false;
    CHECK(!mpu6050_init());
    CHECK(stop_start_reads && gpio_i2c && hardware_writes == 0U);

    reset();
    read_ok = false;
    int16_t x = 1, y = 2, z = 3;
    CHECK(!mpu6050_read(&x, &y, &z));
    CHECK(stop_start_reads && !gpio_i2c);
    CHECK(x == 1 && y == 2 && z == 3);
    CHECK(!mpu6050_read(&x, &y, &z));
    CHECK(gpio_i2c && soft_inits == 0U);
    CHECK(x == 1 && y == 2 && z == 3);
    read_ok = true;
    CHECK(mpu6050_init());
    CHECK(soft_inits == 1U);
    CHECK(mpu6050_read(&x, &y, &z));
    CHECK(x == 0x0102 && y == 0x0304 && z == 0x0506);

    printf("PASS: %u sensor-recovery checks (actual initialization/read functions, injected transport faults)\n", checks);
    return EXIT_SUCCESS;
}
'''


def main() -> None:
    root = Path(__file__).resolve().parent.parent
    source = (root / "firmware" / "board.c").read_text()
    functions = "\n\n".join(
        function(source, name)
        for name in ("mpu_init_write", "mpu6050_init", "mpu6050_read")
    )
    with tempfile.TemporaryDirectory(prefix="haptic-recovery-test-") as temp:
        directory = Path(temp)
        c_file = directory / "test.c"
        executable = directory / "test"
        c_file.write_text(PREFIX + functions + SUFFIX)
        compiler = shlex.split(os.environ.get("CC_HOST", "cc"))
        subprocess.run(
            compiler + ["-std=c11", "-O2", "-Wall", "-Wextra", "-Werror",
                        "-Wpedantic", str(c_file), "-o", str(executable)],
            check=True,
        )
        subprocess.run([str(executable)], check=True)


if __name__ == "__main__":
    main()
