/* Generated with OpenAI Codex; see README.md for attribution.
 * A deterministic wired-AND I2C slave model. It observes physical START/STOP
 * and SCL edges, decodes master bytes, drives ACK/data, and checks final NACK.
 * This exercises the protocol code, not STM32 GPIO registers or Wokwi itself. */
#include "soft_i2c.h"
#include "soft_i2c_test_io.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned checks;
#define CHECK(condition) do { ++checks; if (!(condition)) { \
    fprintf(stderr, "line %d: %s\n", __LINE__, #condition); exit(EXIT_FAILURE); \
} } while (0)

typedef enum { RECEIVE, SLAVE_ACK, TRANSMIT, MASTER_ACK, IDLE } phase_t;
static struct {
    bool scl_release, sda_release, slave_low, hold_scl, acknowledge;
    bool active, address_pending, pointer_pending, next_read, ack_clocked;
    unsigned bits, starts, stops, reads, writes, recovery_clocks, stuck_sda;
    unsigned receive_count, nack_receive;
    uint8_t shift, pointer, registers[256], sent[64];
    bool master_nack[64];
    uint32_t time_us;
    phase_t phase;
} bus;

static bool scl(void) { return bus.scl_release && !bus.hold_scl; }
static bool sda(void)
{
    return bus.sda_release && !bus.slave_low && bus.stuck_sda == 0U;
}

static bool receive_byte(uint8_t byte)
{
    ++bus.receive_count;
    bool ack = bus.acknowledge && bus.receive_count != bus.nack_receive;
    bus.next_read = false;
    if (bus.address_pending) {
        bus.address_pending = false;
        bus.pointer_pending = true;
        ack = ack && (byte >> 1U) == 0x68U;
        bus.next_read = (byte & 1U) != 0U;
    } else if (bus.pointer_pending) {
        bus.pointer = byte;
        bus.pointer_pending = false;
    } else if (ack) {
        bus.registers[bus.pointer++] = byte;
        ++bus.writes;
    }
    return ack;
}

static void rising(void)
{
    if (bus.stuck_sda != 0U) {
        --bus.stuck_sda;
        ++bus.recovery_clocks;
        return;
    }
    if (!bus.active) { return; }
    switch (bus.phase) {
    case RECEIVE:
        bus.shift = (uint8_t)((bus.shift << 1U) | (sda() ? 1U : 0U));
        ++bus.bits;
        break;
    case SLAVE_ACK:
        bus.ack_clocked = true;
        break;
    case TRANSMIT:
        ++bus.bits;
        break;
    case MASTER_ACK:
        CHECK(bus.reads < 64U);
        bus.master_nack[bus.reads] = sda();
        bus.sent[bus.reads] = bus.registers[bus.pointer++];
        ++bus.reads;
        break;
    case IDLE:
        break;
    }
}

static void falling(void)
{
    if (!bus.active) { return; }
    if (bus.phase == RECEIVE && bus.bits == 8U) {
        const bool ack = receive_byte(bus.shift);
        bus.slave_low = ack;
        bus.phase = SLAVE_ACK;
        bus.ack_clocked = false;
        bus.bits = 0U;
        bus.shift = 0U;
    } else if (bus.phase == SLAVE_ACK && bus.ack_clocked) {
        const bool acknowledged = bus.slave_low;
        bus.slave_low = false;
        bus.phase = !acknowledged ? IDLE : (bus.next_read ? TRANSMIT : RECEIVE);
        if (bus.phase == TRANSMIT) {
            bus.slave_low = (bus.registers[bus.pointer] & 0x80U) == 0U;
        }
    } else if (bus.phase == TRANSMIT) {
        if (bus.bits == 8U) {
            bus.slave_low = false;
            bus.phase = MASTER_ACK;
        } else {
            const uint8_t mask = (uint8_t)(0x80U >> bus.bits);
            bus.slave_low = (bus.registers[bus.pointer] & mask) == 0U;
        }
    } else if (bus.phase == MASTER_ACK && bus.reads > 0U) {
        if (bus.master_nack[bus.reads - 1U]) {
            bus.phase = IDLE;
            bus.slave_low = false;
        } else {
            bus.phase = TRANSMIT;
            bus.bits = 0U;
            bus.slave_low = (bus.registers[bus.pointer] & 0x80U) == 0U;
        }
    }
}

void soft_i2c_io_configure(void)
{
    bus.scl_release = true;
    bus.sda_release = true;
}

void soft_i2c_io_scl(bool release)
{
    const bool previous = scl();
    bus.scl_release = release;
    if (!previous && scl()) { rising(); }
    if (previous && !scl()) { falling(); }
}

void soft_i2c_io_sda(bool release)
{
    const bool previous = sda();
    bus.sda_release = release;
    if (scl() && previous && !sda()) {
        ++bus.starts;
        bus.active = true;
        bus.address_pending = true;
        bus.phase = RECEIVE;
        bus.bits = 0U;
        bus.shift = 0U;
    } else if (scl() && !previous && sda()) {
        ++bus.stops;
        bus.active = false;
        bus.phase = IDLE;
        bus.slave_low = false;
    }
}

bool soft_i2c_io_read_scl(void) { ++bus.time_us; return scl(); }
bool soft_i2c_io_read_sda(void) { return sda(); }
uint32_t soft_i2c_io_millis(void) { return bus.time_us / 1000U; }
void soft_i2c_io_delay(void) { bus.time_us += 8U; }

static void reset(void)
{
    memset(&bus, 0, sizeof(bus));
    bus.scl_release = true;
    bus.sda_release = true;
    bus.acknowledge = true;
    bus.phase = IDLE;
    CHECK(soft_i2c_init());
    CHECK(bus.starts == 0U && bus.stops == 0U);
}

int main(void)
{
    reset();
    bus.registers[0x75] = 0x68U;
    uint8_t identity = 0U;
    CHECK(soft_i2c_read_regs(0x68U, 0x75U, &identity, 1U));
    CHECK(identity == 0x68U);
    CHECK(bus.starts == 2U && bus.stops == 1U);
    CHECK(bus.reads == 1U && bus.master_nack[0]);
    CHECK(scl() && sda());

    reset();
    const uint8_t expected[6] = {0x12U, 0x34U, 0xFEU, 0xDCU, 0x40U, 0x00U};
    memcpy(&bus.registers[0x3B], expected, sizeof(expected));
    uint8_t actual[6] = {0U};
    CHECK(soft_i2c_read_regs(0x68U, 0x3BU, actual, sizeof(actual)));
    CHECK(memcmp(actual, expected, sizeof(actual)) == 0);
    CHECK(memcmp(bus.sent, expected, sizeof(expected)) == 0);
    CHECK(bus.starts == 2U && bus.stops == 1U && bus.reads == 6U);
    for (unsigned i = 0U; i < 5U; ++i) { CHECK(!bus.master_nack[i]); }
    CHECK(bus.master_nack[5]);

    reset();
    CHECK(soft_i2c_write_reg(0x68U, 0x6BU, 0x01U));
    CHECK(bus.registers[0x6B] == 0x01U && bus.writes == 1U);
    CHECK(bus.receive_count == 3U && bus.starts == 1U && bus.stops == 1U);

    reset();
    bus.acknowledge = false;
    identity = 0xA5U;
    CHECK(!soft_i2c_read_regs(0x68U, 0x75U, &identity, 1U));
    CHECK(identity == 0xA5U && bus.reads == 0U);
    CHECK(bus.stops == 1U && scl() && sda());

    reset();
    bus.nack_receive = 2U; /* Slave rejects the register-pointer byte. */
    identity = 0xA5U;
    CHECK(!soft_i2c_read_regs(0x68U, 0x75U, &identity, 1U));
    CHECK(identity == 0xA5U && bus.starts == 1U && bus.stops == 1U);

    reset();
    bus.nack_receive = 3U; /* Slave rejects the register-value byte. */
    CHECK(!soft_i2c_write_reg(0x68U, 0x6BU, 0x01U));
    CHECK(bus.registers[0x6B] == 0U && bus.stops == 1U);

    reset();
    bus.hold_scl = true;
    identity = 0xA5U;
    CHECK(!soft_i2c_read_regs(0x68U, 0x75U, &identity, 1U));
    CHECK(identity == 0xA5U);
    CHECK(bus.scl_release && bus.sda_release && bus.time_us < 20000U);

    reset();
    bus.hold_scl = true;
    CHECK(!soft_i2c_init());
    CHECK(bus.scl_release && bus.sda_release && bus.time_us < 10000U);

    reset();
    bus.stuck_sda = 9U;
    CHECK(soft_i2c_init());
    CHECK(bus.recovery_clocks == 9U && scl() && sda());

    reset();
    CHECK(!soft_i2c_read_regs(0x80U, 0U, actual, 1U));
    CHECK(!soft_i2c_read_regs(0x68U, 0U, NULL, 1U));
    CHECK(!soft_i2c_read_regs(0x68U, 0U, actual, 0U));
    CHECK(!soft_i2c_read_regs(0x68U, 0U, actual, SOFT_I2C_MAX_READ + 1U));
    CHECK(!soft_i2c_write_reg(0x80U, 0U, 0U));
    CHECK(bus.starts == 0U && bus.stops == 0U);

    printf("PASS: %u software-I2C checks (wire protocol, ACK/NACK, burst, timeout, recovery)\n", checks);
    return EXIT_SUCCESS;
}
