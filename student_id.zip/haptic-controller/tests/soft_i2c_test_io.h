#ifndef SOFT_I2C_TEST_IO_H
#define SOFT_I2C_TEST_IO_H
#include <stdbool.h>
#include <stdint.h>
void soft_i2c_io_configure(void);
void soft_i2c_io_scl(bool release);
void soft_i2c_io_sda(bool release);
bool soft_i2c_io_read_scl(void);
bool soft_i2c_io_read_sda(void);
uint32_t soft_i2c_io_millis(void);
void soft_i2c_io_delay(void);
#endif
