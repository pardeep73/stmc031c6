#include "haptic.h"

/* Generated with OpenAI Codex; not independently student-authored code.
 * Assignment 2 formulas and one-sided release hysteresis are authoritative. */

#include <math.h>
#include <stddef.h>

#define RAD_TO_DEG 57.29577951308232f
#define HYSTERESIS_DEG 5.0f
#define DEBOUNCE_MS 30u

static float limit(float value, float lower, float upper)
{
    return fminf(fmaxf(value, lower), upper);
}

region_t region_update(region_t previous, float magnitude,
                       float free_boundary, float clamp_boundary)
{
    /* Check the most distant destination first: slider steps can skip a region.
     * Each axis owns its previous state, so the release deadband has memory. */
    if (previous == REGION_FREE) {
        if (magnitude >= clamp_boundary) return REGION_CLAMP;
        if (magnitude >= free_boundary) return REGION_COMPLIANT;
    } else if (previous == REGION_COMPLIANT) {
        if (magnitude >= clamp_boundary) return REGION_CLAMP;
        if (magnitude <= free_boundary - HYSTERESIS_DEG) return REGION_FREE;
    } else {
        if (magnitude <= free_boundary - HYSTERESIS_DEG) return REGION_FREE;
        if (magnitude <= clamp_boundary - HYSTERESIS_DEG) return REGION_COMPLIANT;
    }
    return previous;
}

bool angles_from_accel(int16_t x, int16_t y, int16_t z, angles_t *angles)
{
    if (angles == NULL || (x == 0 && y == 0 && z == 0)) return false;
    const float ax = (float)x / 16384.0f;
    const float ay = (float)y / 16384.0f;
    const float az = (float)z / 16384.0f;
    /* Assignment Eq. (1)-(2): roll is four-quadrant; pitch inverts X. */
    angles->pitch_deg = atan2f(-ax, sqrtf(ay * ay + az * az)) * RAD_TO_DEG;
    angles->roll_deg = atan2f(ay, az) * RAD_TO_DEG;
    angles->tilt_deg = sqrtf(angles->pitch_deg * angles->pitch_deg +
                             angles->roll_deg * angles->roll_deg);
    return true;
}

void haptic_init(haptic_t *state)
{
    /* Used at boot and on every invalid sample. A fault never restores MANUAL. */
    *state = (haptic_t){
        .mode = MODE_AUTOPILOT, .fault = true,
        .pitch_region = REGION_FREE, .roll_region = REGION_FREE,
        .tilt_region = REGION_FREE,
        .pitch_servo_deg = 90.0f, .roll_servo_deg = 90.0f,
        .tilt_servo_deg = 0.0f
    };
}

static float axis_servo(region_t region, float angle)
{
    if (region == REGION_FREE) return 90.0f;
    if (region == REGION_CLAMP) return angle < 0.0f ? 140.0f : 40.0f;
    /* Explicit saturation also protects against arithmetic or input rounding. */
    /* The Wokwi horn's increasing angle rotates clockwise. The assignment
     * calls clockwise negative, so positive pitch/roll must decrease the
     * absolute servo angle relative to its 90-degree center. */
    return limit(90.0f - angle, 40.0f, 140.0f);
}

void haptic_step(haptic_t *state, const angles_t *angles, bool button_pressed)
{
    /* Check before using angle values; stale/missing samples must not drive
     * feedback. Roll is four-quadrant, so its valid range extends to ±180°. */
    if (angles == NULL || !isfinite(angles->pitch_deg) ||
        !isfinite(angles->roll_deg) || !isfinite(angles->tilt_deg) ||
        fabsf(angles->pitch_deg) > 90.0f || fabsf(angles->roll_deg) > 180.0f ||
        angles->tilt_deg < 0.0f || angles->tilt_deg > 201.25f) {
        haptic_init(state);
        return;
    }
    state->fault = false;
    const float pitch = fabsf(angles->pitch_deg);
    const float roll = fabsf(angles->roll_deg);
    state->pitch_region = region_update(state->pitch_region, pitch, 30.0f, 50.0f);
    state->roll_region = region_update(state->roll_region, roll, 30.0f, 50.0f);
    state->tilt_region = region_update(state->tilt_region, angles->tilt_deg, 20.0f, 70.0f);

    const bool both_clamped = state->pitch_region == REGION_CLAMP &&
                              state->roll_region == REGION_CLAMP;
    const bool safe_handover = state->pitch_region == REGION_FREE &&
                               state->roll_region == REGION_FREE &&
                               pitch < 30.0f && roll < 30.0f;
    /* Consume each debounced event in this update; unsafe presses are not saved.
     * Use one mutually exclusive branch so a press cannot toggle twice. */
    if (state->mode == MODE_MANUAL) {
        if (button_pressed || both_clamped) state->mode = MODE_AUTOPILOT;
    } else if (button_pressed && safe_handover) {
        state->mode = MODE_MANUAL;
    }

    state->pitch_servo_deg = axis_servo(state->pitch_region, angles->pitch_deg);
    state->roll_servo_deg = axis_servo(state->roll_region, angles->roll_deg);
    state->tilt_servo_deg = state->tilt_region == REGION_FREE ? 0.0f :
        (state->tilt_region == REGION_CLAMP ? 140.0f :
         limit(2.0f * angles->tilt_deg, 0.0f, 140.0f));
}

void button_init(button_t *button, bool initial, uint32_t now_ms)
{
    *button = (button_t){.stable = initial, .candidate = initial, .changed_ms = now_ms};
}

bool button_update(button_t *button, bool raw, uint32_t now_ms)
{
    /* Restart the settling interval whenever the raw input bounces. Unsigned
     * subtraction remains correct when the millisecond counter wraps. */
    if (raw != button->candidate) {
        button->candidate = raw;
        button->changed_ms = now_ms;
    }
    if (button->candidate != button->stable &&
        (uint32_t)(now_ms - button->changed_ms) >= DEBOUNCE_MS) {
        button->stable = button->candidate;
        return button->stable;
    }
    return false;
}

uint16_t servo_pulse_us(float degrees)
{
    /* Round to the nearest microsecond; this value is also the TIM3 compare. */
    if (!isfinite(degrees)) return 1500u;
    return (uint16_t)(1000.0f + limit(degrees, 0.0f, 180.0f) * (1000.0f / 180.0f) + 0.5f);
}
